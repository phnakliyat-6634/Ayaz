package com.resul.ayaz

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer

/**
 * Listens only for the word "Ayaz" with the small offline model (fast and exact
 * for a single word). It keeps the last few seconds of sound so the speaker check
 * can run on the very moment "Ayaz" was said, after the microphone is handed to
 * Google's speech recognition for the command itself.
 */
class WakeListener(
    private val model: Model,
    private val isSleeping: () -> Boolean,
    private val onWake: (kind: Kind, pcm: ShortArray) -> Unit,
    private val onFail: (String) -> Unit,
    private val minConf: () -> Float,
    private val onLog: (String) -> Unit
) {
    enum class Kind { COMMAND, OPEN }

    @Volatile private var running = false
    private var thread: Thread? = null

    private val RATE = 16000
    private val ring = ShortArray(RATE * 3)
    private var ringPos = 0
    private var ringFilled = false

    @SuppressLint("MissingPermission")
    fun start() {
        if (running) return
        running = true
        thread = Thread {
            var ar: AudioRecord? = null
            var rec: Recognizer? = null
            try {
                val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                ar = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, RATE))
                if (ar.state != AudioRecord.STATE_INITIALIZED) throw Exception("mikrofon kullanımda")
                rec = Recognizer(model, RATE.toFloat(), "[\"ayaz\", \"ayaz aç\", \"[unk]\"]")
                rec.setWords(true)      // per-word confidence
                ar.startRecording()
                val buf = ShortArray(RATE / 10)   // 100 ms
                while (running) {
                    val n = ar.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    push(buf, n)
                    val sleeping = isSleeping()
                    // only whole, finished words count: a sound that merely resembles "ayaz" mid-sentence is ignored
                    if (rec.acceptWaveForm(buf, n)) {
                        val o = JSONObject(rec.result)
                        val text = o.optString("text").trim()
                        if (text != "ayaz" && text != "ayaz aç") continue
                        val words = o.optJSONArray("result")
                        var conf = 0.0
                        if (words != null) for (i in 0 until words.length()) {
                            val w = words.getJSONObject(i)
                            if (w.optString("word") == "ayaz") conf = w.optDouble("conf", 0.0)
                        }
                        if (conf < minConf()) { onLog("\"Ayaz\" benzeri ses duyuldu ama emin değilim (%.2f), dinlemeye geçmedim".format(conf)); continue }
                        if (sleeping && text == "ayaz aç") { fire(Kind.OPEN); break }
                        if (!sleeping && text == "ayaz") { fire(Kind.COMMAND); break }
                    }
                }
            } catch (e: Exception) {
                if (running) onFail(e.message ?: "dinleme hatası")
            } finally {
                running = false
                try { ar?.stop() } catch (_: Exception) {}
                try { ar?.release() } catch (_: Exception) {}
                try { rec?.close() } catch (_: Exception) {}
            }
        }.also { it.start() }
    }

    fun stop() {
        running = false
        try { thread?.join(500) } catch (_: Exception) {}
        thread = null
    }

    val active get() = running

    private fun push(buf: ShortArray, n: Int) {
        for (i in 0 until n) {
            ring[ringPos] = buf[i]
            ringPos = (ringPos + 1) % ring.size
            if (ringPos == 0) ringFilled = true
        }
    }

    /** the last ~2.5 seconds of sound, oldest first */
    private fun snapshot(): ShortArray {
        val len = minOf(if (ringFilled) ring.size else ringPos, (RATE * 2.5).toInt())
        val out = ShortArray(len)
        var p = (ringPos - len + ring.size) % ring.size
        for (i in 0 until len) { out[i] = ring[p]; p = (p + 1) % ring.size }
        return out
    }

    private fun fire(kind: Kind) {
        running = false
        onWake(kind, snapshot())
    }
}
