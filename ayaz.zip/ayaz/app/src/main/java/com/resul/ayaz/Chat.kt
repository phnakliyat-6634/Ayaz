package com.resul.ayaz

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Small talk: Yozgat dialect or standard Turkish. Uses Gemini when a key is saved, built-in replies otherwise. */
object Chat {
    fun yozgat(c: Context) = Prefs.dialect(c) == "yozgat"

    /** Ayaz's own sentences in Yozgat style: "arıyorum" -> "arıyom", "gönderildi" -> "gönderdim gari" */
    fun styled(c: Context, text: String): String {
        if (!yozgat(c)) return text
        var t = text
        val whole = mapOf(
            "Buradayım" to "Buradayım gari",
            "Zaten açığım" to "Açığım gari, nörüyon?",
            "Gönderildi" to "Gönderdim gari",
            "Duyamadım" to "Duyamadım gari, bi daha de",
            "Seni duyamadım" to "Duyamadım gari, bi daha de",
            "Tamam, aramıyorum" to "Hee tamam, aramıyom",
            "Tamam, açmıyorum" to "Hee tamam, açmıyom",
            "Tamam, iptal ettim" to "Hee, iptal ettim",
            "Mesajı iptal ettim" to "Mesajı sildim gari"
        )
        whole[t]?.let { return it }
        t = t.replace(Regex("(?<=\\p{L})(ı|i|u|ü)yorum(?!\\p{L})"), "$1yom")
            .replace(Regex("(?<=\\p{L})(ı|i|u|ü)yorsun(?!\\p{L})"), "$1yon")
            .replace(Regex("(?<!\\p{L})Bunu anlayamadım"), "Bunu annamadım gari")
            .replace(Regex("(?<!\\p{L})bulamadım(?!\\p{L})"), "bulamadım gari")
        return t
    }

    private val SMALL_TALK = Regex("(?<!\\p{L})(nörüyon|nöryon|nörüyosun|nasılsın|naber|nabıyon|napıyon|naptın|ne yapıyorsun|ne yapıyon|neydiyon|" +
        "günaydın|iyi geceler|hayırlı geceler|iyi akşamlar|hayırlı akşamlar|teşekkür|sağ ol|sağol|eyvallah|merhaba|selam|selamün aleyküm|" +
        "kimsin|adın ne|seni seviyorum|canım sıkıldı|sıkıldım|şaka yap|fıkra anlat|acıktım|yoruldum|iyiyim|ben de iyiyim|nerelisin|hoşça kal|görüşürüz)(?!\\p{L})")

    fun isSmallTalk(t: String) = SMALL_TALK.containsMatchIn(t) && t.split(" ").size <= 7

    private val history = ArrayList<Pair<String, String>>()     // (who, text)

    /** built-in replies when there is no Gemini key (or it fails) */
    fun builtIn(c: Context, t: String): String {
        val y = yozgat(c)
        fun r(yoz: String, std: String) = if (y) yoz else std
        return when {
            Regex("nörüyon|nöryon|nasılsın|naber|nabıyon|napıyon|neydiyon").containsMatchIn(t) ->
                r(listOf("İyiyim gari, sen nörüyon?", "Hee iyiyim, şükür. Sen nörüyon?", "İyiyim gari, bi emrin var mı?").random(),
                  listOf("İyiyim, sen nasılsın?", "İyiyim, teşekkür ederim. Sen nasılsın?").random())
            Regex("ne yapıyorsun|ne yapıyon|naptın").containsMatchIn(t) ->
                r("Seni bekliyom gari, bi emrin var mı?", "Seni bekliyorum, bir isteğin var mı?")
            Regex("(?<!\\p{L})(ben de )?iyiyim").containsMatchIn(t) -> r("Hee iyi olsun, hep iyi ol gari.", "Çok sevindim.")
            t.contains("günaydın") -> r("Günaydın gari, hayırlı sabahlar.", "Günaydın, iyi sabahlar.")
            Regex("iyi geceler|hayırlı geceler").containsMatchIn(t) -> r("Hayırlı geceler, rahat uyu gari.", "İyi geceler, tatlı rüyalar.")
            Regex("iyi akşamlar|hayırlı akşamlar").containsMatchIn(t) -> r("Hayırlı akşamlar gari.", "İyi akşamlar.")
            Regex("teşekkür|sağ ol|sağol|eyvallah").containsMatchIn(t) -> r("Ne demek, sağ olasın gari.", "Rica ederim.")
            Regex("selamün aleyküm").containsMatchIn(t) -> r("Aleyküm selam gari, nörüyon?", "Aleyküm selam.")
            Regex("merhaba|selam").containsMatchIn(t) -> r("Selam gari, nörüyon?", "Merhaba, nasılsın?")
            Regex("kimsin|adın ne").containsMatchIn(t) -> r("Ben Ayaz'ım gari, senin yardımcın.", "Ben Ayaz, senin yardımcın.")
            t.contains("nerelisin") -> r("Yozgatlıyım gari, nereli olacam?", "Ben bu telefonun içinde yaşıyorum.")
            t.contains("seni seviyorum") -> r("Ben de seni severim gari, a gadanı alıyım.", "Ben de seni seviyorum.")
            Regex("canım sıkıldı|sıkıldım").containsMatchIn(t) -> r("Sıkılma gari, bi çay koy da muhabbet edelim.", "Sıkılma, istersen bir şarkı açayım.")
            t.contains("acıktım") -> r("Acıktın mı? Bi arabaşı çorbası iyi gider gari.", "Acıktın mı? Bir şeyler yesen iyi olur.")
            t.contains("yoruldum") -> r("Otur bi soluklan gari, çayını iç.", "Biraz dinlen, iyi gelir.")
            Regex("hoşça kal|görüşürüz").containsMatchIn(t) -> r("Eyvallah, gine bekleriz gari.", "Görüşürüz.")
            Regex("şaka yap|fıkra anlat").containsMatchIn(t) -> listOf(
                r("Adamın biri bakkala gitmiş, ekmek var mı demiş. Bakkal var demiş. Adam iyi bari demiş, gitmiş gari.", "Adamın biri bakkala gitmiş, ekmek var mı demiş. Bakkal var demiş. Adam iyi bari demiş, gitmiş."),
                r("Telefonum bana dedi ki, şarjım bitiyo gari. Ben de dedim, benim de sabrım.", "Telefonum bana şarjım bitiyor dedi. Ben de benim de sabrım dedim.")
            ).random()
            else -> r("Hee gari, anladım.", "Anladım.")
        }
    }

    /** a reply with Gemini (keeps a short memory of the conversation); null if not possible */
    fun ai(c: Context, said: String): String? {
        val key = Prefs.geminiKey(c)
        if (key.isBlank()) return null
        val style = if (yozgat(c))
            "Yozgat ağzıyla konuş: 'nörüyon', 'gari', 'hee', 'bööle', 'şindi', 'gine', 'a gadanı alıyım', '-yom/-yon' ekleri gibi. Samimi, sıcak ve saygılı ol, kimseyle alay etme."
        else "Samimi, sıcak, sade bir Türkçeyle konuş."
        val past = history.takeLast(8).joinToString("\n") { "${it.first}: ${it.second}" }
        val prompt = """
            Sen Ayaz'sın; kullanıcının telefonundaki sesli asistan ve sohbet arkadaşısın. $style
            Cevabın sesli okunacak: en fazla 2 kısa cümle, emoji ve işaret kullanma.
            Önceki konuşma:
            $past
            Kullanıcı: $said
            Ayaz:
        """.trimIndent()
        return try {
            val conn = URL("https://generativelanguage.googleapis.com/v1beta/interactions").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"; conn.doOutput = true
            conn.connectTimeout = 10000; conn.readTimeout = 25000
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            val body = JSONObject().put("model", "gemini-3.1-flash-lite").put("input", prompt)
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            if (conn.responseCode !in 200..299) return null
            val o = JSONObject(conn.inputStream.bufferedReader().readText())
            val sb = StringBuilder()
            fun walk(x: Any?) {
                when (x) {
                    is JSONObject -> { if (x.optString("type") == "text" && x.has("text")) sb.append(x.optString("text")) else for (k in x.keys()) walk(x.opt(k)) }
                    is JSONArray -> for (i in 0 until x.length()) walk(x.opt(i))
                }
            }
            val steps = o.optJSONArray("steps")
            if (steps != null) for (i in 0 until steps.length()) steps.optJSONObject(i)?.let { if (it.optString("type") == "model_output") walk(it.opt("content")) }
            if (sb.isBlank()) walk(o)
            sb.toString().replace(Regex("[*#`_]"), "").replace(Regex("^Ayaz:\\s*"), "").trim().ifBlank { null }
        } catch (e: Exception) { null }
    }

    fun remember(who: String, text: String) {
        history += who to text
        while (history.size > 12) history.removeAt(0)
    }
}
