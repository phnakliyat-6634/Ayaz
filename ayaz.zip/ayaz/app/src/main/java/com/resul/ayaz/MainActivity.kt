package com.resul.ayaz

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService

class MainActivity : Activity() {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var col: LinearLayout
    private val checks = mutableListOf<() -> Unit>()
    private var enrollService: SpeechService? = null

    private val INK = Color.parseColor("#18203A")
    private val MUTED = Color.parseColor("#5E6782")
    private val SIGNAL = Color.parseColor("#FF9F1C")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#E9ECF2")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(40))
        }
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#E9ECF2")); addView(col) }
        setContentView(scroll)
        build()
    }

    override fun onResume() { super.onResume(); checks.forEach { it() } }
    override fun onDestroy() { stopEnroll(); super.onDestroy() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(s: String, size: Float = 16f, color: Int = INK, bold: Boolean = false, top: Int = 0) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(top), 0, dp(4))
        }.also { col.addView(it) }

    private fun button(label: String, primary: Boolean = false, onClick: () -> Unit) =
        Button(this).apply {
            text = label; isAllCaps = false; textSize = 16f
            setTextColor(if (primary) INK else INK)
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(if (primary) SIGNAL else Color.WHITE)
                setStroke(dp(1), Color.parseColor("#CDD3E0"))
            }
            setOnClickListener { onClick() }
        }.also {
            it.minHeight = dp(52)
            it.setPadding(dp(16), dp(12), dp(16), dp(12))
            col.addView(it, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        }

    /** a permission row: label + status, button opens the setting */
    private fun step(label: String, ok: () -> Boolean, open: () -> Unit) {
        val b = button(label) { open() }
        checks += { b.text = (if (ok()) "✓  " else "○  ") + label }
    }

    private fun build() {
        text("Ayaz", 34f, bold = true)
        text("Kurulumu yukarıdan aşağıya bir kez yap. Sonra Ayaz arka planda çalışır; bildirim panelindeki Ayaz kutucuğundan açıp kapatabilirsin.", 15f, MUTED)

        text("1. İzinler", 20f, bold = true, top = 24)
        val runtime = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR, Manifest.permission.SEND_SMS,
            Manifest.permission.CALL_PHONE, Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) runtime += Manifest.permission.POST_NOTIFICATIONS
        step("Mikrofon, kamera, rehber, takvim, SMS, arama, bildirim",
            { runtime.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED } }) {
            requestPermissions(runtime.toTypedArray(), 1)
        }
        step("Diğer uygulamaların üzerinde göster", { Settings.canDrawOverlays(this) }) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        step("Erişilebilirlik (mesaj gönderme ve düzeltme)", { AyazAccessibility.instance != null || accessibilityOn() }) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        step("Bildirim erişimi (mesajları sesli okuma)",
            { NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName) }) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        step("Pil kısıtlamasını kaldır", {
            getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        }) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        step("Güncellemeleri kurma izni", { packageManager.canRequestPackageInstalls() }) {
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
        }
        text("Xiaomi için ayrıca: Uygulama bilgisi > Otomatik başlatma AÇIK, Pil tasarrufu > Kısıtlama yok, Diğer izinler > \"Arka planda çalışırken açılır pencereleri göster\" ve \"Kilit ekranında göster\" İZİN VER.", 14f, MUTED, top = 8)
        button("Xiaomi uygulama ayarlarını aç") { openXiaomi() }

        text("2. Ses modeli", 20f, bold = true, top = 24)
        text("Türkçe ses ve ses tanıma modeli (yaklaşık 50 MB). Wi-Fi'de bir kez indirilir, sonra internetsiz çalışır.", 14f, MUTED)
        val modelStatus = text("", 15f)
        val dl = button("Modeli indir", primary = true) {}
        dl.setOnClickListener {
            dl.isEnabled = false
            ModelManager.download(this, { m -> main.post { modelStatus.text = m } }) { ok ->
                main.post { dl.isEnabled = true; modelStatus.text = if (ok) "Model hazır ✓" else modelStatus.text; checks.forEach { it() } }
            }
        }
        checks += { if (ModelManager.ready(this)) { modelStatus.text = "Model hazır ✓"; dl.visibility = View.GONE } }

        text("3. Sesimi tanıt", 20f, bold = true, top = 24)
        text("Sessiz bir yerde 5 kez, her seferinde kısa bir ara vererek \"Ayaz\" ile başlayan bir cümle söyle (örnek: \"Ayaz, YouTube'u aç\"). Ayaz bundan sonra başkalarının sesine tepki vermez.", 14f, MUTED)
        val enrollStatus = text("", 15f)
        button("Ses kaydını başlat") { enroll(enrollStatus) }
        button("Ses kaydını sil (herkese cevap verir)") {
            Prefs.setVoice(this, null); enrollStatus.text = "Ses kaydı silindi"
        }
        checks += { if (enrollStatus.text.isEmpty()) enrollStatus.text = if (Prefs.voice(this) != null) "Sesin kayıtlı ✓" else "Henüz ses kaydı yok" }

        val thrLabel = text("", 14f, MUTED, top = 8)
        val seek = SeekBar(this).apply { max = 70 }
        col.addView(seek)
        fun showThr() {
            val last = Prefs.lastDistance(this)
            thrLabel.text = "Ses eşiği: %.2f   (son ölçülen: %s)\nSesini reddediyorsa eşiği sağa, başkalarını kabul ediyorsa sola çek.".format(
                Prefs.threshold(this), if (last < 0) "-" else "%.2f".format(last))
        }
        seek.progress = ((Prefs.threshold(this) - 0.2f) * 100).toInt()
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) { Prefs.setThreshold(this@MainActivity, 0.2f + p / 100f); showThr() }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        checks += { showThr() }

        text("4. Ayaz", 20f, bold = true, top = 24)
        val runBtn = button("", primary = true) {}
        runBtn.setOnClickListener {
            if (AyazService.running) AyazService.stop(this)
            else {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    toast("Önce mikrofon iznini ver"); return@setOnClickListener
                }
                if (!ModelManager.ready(this)) { toast("Önce ses modelini indir"); return@setOnClickListener }
                stopEnroll()
                AyazService.start(this)
            }
            main.postDelayed({ checks.forEach { it() } }, 600)
        }
        checks += { runBtn.text = if (AyazService.running) "Ayaz'ı durdur" else "Ayaz'ı başlat" }
        text("Bildirim panelini aşağı çek, kalem simgesiyle düzenle ve Ayaz kutucuğunu ekle. Kutucuğa dokununca açılır/kapanır, basılı tutunca bu ekran açılır.", 14f, MUTED)

        text("El hareketleri", 20f, bold = true, top = 24)
        text("YouTube, Instagram, Facebook ve TikTok açıkken ön kamera elini izler: yukarı kaldırınca sonraki, yana kaydırınca önceki video. Kamera sadece bu uygulamalarda açılır. Sesle de: \"Ayaz, el hareketlerini aç/kapat\".", 14f, MUTED)
        val gBtn = button("") {}
        gBtn.setOnClickListener {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.CAMERA), 2); return@setOnClickListener
            }
            Prefs.setGestures(this, !Prefs.gestures(this))
            if (!Prefs.gestures(this)) AyazService.instance?.stopGestures()
            else toast("Kamera izni yeni verildiyse Ayaz'ı durdurup tekrar başlat")
            checks.forEach { it() }
        }
        checks += { gBtn.text = if (Prefs.gestures(this)) "El hareketleri: AÇIK" else "El hareketleri: KAPALI" }
        val invBtn = button("") {}
        invBtn.setOnClickListener { Prefs.setInvertGesture(this, !Prefs.invertGesture(this)); checks.forEach { it() } }
        checks += { invBtn.text = if (Prefs.invertGesture(this)) "Yukarı/aşağı yönü: TERS" else "Yukarı/aşağı yönü: NORMAL" }
        text("Elini yukarı kaldırdığında önceki videoya gidiyorsa yönü TERS yap.", 13f, MUTED)

        text("5. Güncelleme", 20f, bold = true, top = 24)
        text("GitHub depo adın (örnek: resulkarabulut/ayaz)", 14f, MUTED)
        val repo = EditText(this).apply {
            setText(Prefs.repo(this@MainActivity)); inputType = InputType.TYPE_CLASS_TEXT
            hint = "kullaniciadi/ayaz"
        }
        col.addView(repo)
        button("Kaydet ve güncelleme kontrol et") {
            Prefs.setRepo(this, repo.text.toString())
            Updater.check(this, interactive = true) { toast(it) }
        }
        text("Sürüm ${BuildConfig.VERSION_NAME}", 13f, MUTED)

        text("Komut örnekleri", 20f, bold = true, top = 24)
        text(listOf(
            "Tek nefeste söyle: \"Ayaz, Google'ı aç\". Sadece \"Ayaz\" dersen bip sesinden sonra komutu söyle:",
            "• Mobile Legends'ı aç / Instagram'a gir / Google'ı kapat", "• Annemi ara  /  geri dön  /  ana ekran", "• YouTube'da Barış Manço aç", "• Kadıköy'e yol tarifi → Ayaz, konuma başla",
            "• Babama WhatsApp'tan geliyorum yaz → Ayaz, gönder",
            "• geliyorum yerine geldim yaz  /  son kelimeyi sil  /  iptal",
            "• Mesajları oku", "• Her perşembe sabah 8'e alarm kur",
            "• Yarın saat 3'te diş randevusunu hatırlat", "• Televizyonu aç / sesini kıs / 5. kanalı aç",
            "• Facebook Reels'i aç / Instagram Reels / YouTube Shorts", "• El hareketlerini aç / kapat", "• Yarın hava nasıl? (Gemini'ye sorar)",
            "• Claude'u aç  /  Araştır: en iyi nakliye sigortası", "• Güncelleme var mı",
            "\"Ayaz kapat\" (uyku) ve \"Ayaz aç\" (uyan)"
        ).joinToString("\n"), 15f)

        text("Son olaylar", 20f, bold = true, top = 24)
        val logTv = text("", 13f, MUTED)
        button("Yenile") { logTv.text = Prefs.logText(this).lines().reversed().joinToString("\n") }
        checks += { logTv.text = Prefs.logText(this).lines().reversed().joinToString("\n") }
    }

    private fun accessibilityOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/")
    }

    private fun openXiaomi() {
        val tries = listOf(
            Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
            Intent("miui.intent.action.APP_PERM_EDITOR").putExtra("extra_pkgname", packageName),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )
        for (i in tries) { try { startActivity(i); return } catch (_: Exception) {} }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    // ---------- voice enrollment ----------
    private fun enroll(status: TextView) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { toast("Önce mikrofon iznini ver"); return }
        if (!ModelManager.ready(this)) { toast("Önce ses modelini indir"); return }
        if (AyazService.running) AyazService.stop(this)
        stopEnroll()
        status.text = "Hazırlanıyor…"
        Thread {
            try {
                val (m, spk) = ModelManager.load(this)
                main.post {
                    val r = Recognizer(m, 16000f)
                    r.setSpeakerModel(spk)
                    val vecs = mutableListOf<FloatArray>()
                    status.text = "Şimdi \"Ayaz\" de (0/5)"
                    val svc = SpeechService(r, 16000f)
                    enrollService = svc
                    svc.startListening(object : RecognitionListener {
                        override fun onPartialResult(h: String?) {}
                        override fun onResult(h: String?) { take(h) }
                        override fun onFinalResult(h: String?) { take(h) }
                        override fun onError(e: Exception?) { status.text = "Hata: ${e?.message}" }
                        override fun onTimeout() {}
                        private fun take(h: String?) {
                            val o = try { JSONObject(h ?: return) } catch (e: Exception) { return }
                            if (afterWake(o.optString("text")) == null) return
                            val v = Voice.vec(o) ?: return
                            vecs += v
                            if (vecs.size >= 5) {
                                Prefs.setVoice(this@MainActivity, Voice.avg(vecs))
                                stopEnroll()
                                status.text = "Sesin kaydedildi ✓  Şimdi Ayaz'ı başlatabilirsin."
                            } else status.text = "Tekrar \"Ayaz\" de (${vecs.size}/5)"
                        }
                    })
                }
            } catch (e: Exception) {
                main.post { status.text = "Model yüklenemedi: ${e.message}" }
            }
        }.start()
    }

    private fun stopEnroll() {
        try { enrollService?.stop(); enrollService?.shutdown() } catch (_: Exception) {}
        enrollService = null
    }
}
