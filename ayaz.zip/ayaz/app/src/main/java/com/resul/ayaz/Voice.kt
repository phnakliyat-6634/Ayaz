package com.resul.ayaz

import android.content.Context
import org.json.JSONObject
import kotlin.math.sqrt

/** Speaker check with Vosk x-vectors: compares the voice that said "Ayaz" with the enrolled one. */
object Voice {
    fun vec(o: JSONObject): FloatArray? {
        val a = o.optJSONArray("spk") ?: return null
        return FloatArray(a.length()) { a.getDouble(it).toFloat() }
    }

    fun dist(a: FloatArray, b: FloatArray): Float {
        var d = 0.0; var na = 0.0; var nb = 0.0
        for (i in a.indices) { d += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i] }
        if (na == 0.0 || nb == 0.0) return 1f
        return (1.0 - d / (sqrt(na) * sqrt(nb))).toFloat()
    }

    fun avg(list: List<FloatArray>): FloatArray {
        val out = FloatArray(list[0].size)
        for (v in list) for (i in out.indices) out[i] += v[i] / list.size
        return out
    }

    /** speaker check on the sound around "Ayaz" (runs off the main thread) */
    fun verifyPcm(c: Context, model: org.vosk.Model, spk: org.vosk.SpeakerModel?, pcm: ShortArray): Boolean {
        if (Prefs.voice(c) == null) return true
        if (spk == null) return true
        var r: org.vosk.Recognizer? = null
        return try {
            r = org.vosk.Recognizer(model, 16000f, "[\"ayaz\", \"[unk]\"]")
            r.setSpeakerModel(spk)
            r.acceptWaveForm(pcm, pcm.size)
            verify(c, vec(JSONObject(r.finalResult)))
        } catch (e: Exception) { true } finally { try { r?.close() } catch (_: Exception) {} }
    }

    /** true = accepted. With no enrolled voice every speaker is accepted. */
    fun verify(c: Context, v: FloatArray?): Boolean {
        val ref = Prefs.voice(c) ?: return true
        if (v == null || v.size != ref.size) return false
        val d = dist(v, ref)
        Prefs.setLastDistance(c, d)
        return d <= Prefs.threshold(c)
    }
}
