package com.resul.ayaz

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Handler
import android.os.Looper

object Locator {
    fun allowed(c: Context) =
        c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** current position (fresh if possible, otherwise the last known), on the main thread */
    @SuppressLint("MissingPermission")
    fun get(c: Context, cb: (Location?) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        if (!allowed(c)) { main.post { cb(null) }; return }
        val lm = c.getSystemService(LocationManager::class.java)
        var done = false
        val finish: (Location?) -> Unit = { l -> if (!done) { done = true; main.post { cb(l) } } }
        val last = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { try { lm.getLastKnownLocation(it) } catch (_: Exception) { null } }
            .maxByOrNull { it.time }
        main.postDelayed({ finish(last) }, 8000)
        val provider = when {
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            else -> null
        }
        if (provider == null) { finish(last); return }
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                lm.getCurrentLocation(provider, null, c.mainExecutor) { l -> finish(l ?: last) }
            } else {
                @Suppress("DEPRECATION")
                lm.requestSingleUpdate(provider, { l -> finish(l) }, Looper.getMainLooper())
            }
        } catch (_: Exception) { finish(last) }
    }

    /** district or city name for a position (off the main thread) */
    fun placeName(c: Context, l: Location): String? = try {
        @Suppress("DEPRECATION")
        val a = Geocoder(c, TR).getFromLocation(l.latitude, l.longitude, 1)?.firstOrNull()
        a?.subAdminArea ?: a?.subLocality ?: a?.locality ?: a?.adminArea
    } catch (_: Exception) { null }

    fun mapsLink(l: Location) = "https://maps.google.com/?q=%.6f,%.6f".format(java.util.Locale.US, l.latitude, l.longitude)
}
