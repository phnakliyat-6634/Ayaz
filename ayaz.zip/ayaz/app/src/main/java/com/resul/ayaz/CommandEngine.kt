package com.resul.ayaz

import android.Manifest
import android.app.SearchManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.telephony.SmsManager
import java.text.SimpleDateFormat
import java.util.TimeZone

class CommandEngine(private val s: AyazService) {

    data class Draft(val type: String, val name: String, val number: String, var text: String, val more: List<String> = emptyList())

    private var draft: Draft? = null
    private var lastDestination: String? = null
    private val c: Context get() = s

    private fun has(t: String, vararg words: String) = words.any { t.contains(it) }
    private fun enc(x: String) = Uri.encode(x)
    private fun w(word: String) = Regex("(?<!\\p{L})$word(?!\\p{L})")

    /** quick = text came from the offline listener in the same breath as "Ayaz" */
    fun handle(raw: String, conf: Float, quick: Boolean = false) {
        val t = normalizeBrands(trLower(raw)).removePrefix("ayaz ").trim()
        s.log("Sen: $raw")
        Chat.observe(raw)
        when {
            t.isEmpty() -> s.say("Seni duyamadım")
            draft != null && Regex("^(mesajı |onu |hemen )?(gönder|yolla)( bakalım| hadi)?$").matches(t) -> sendDraft()
            draft != null && (has(t, "düzelt", " yerine ", "kelimesini", "son kelimeyi sil", "değiştir")) -> fixDraft(t)
            draft != null && w("(iptal|vazgeç)").containsMatchIn(t) -> { draft = null; s.say("Mesajı iptal ettim") }
            has(t, "güncelleme") -> Updater.check(c, interactive = true) { s.say(it) }
            Chat.isSmallTalk(t) && !isMessage(t) && !isCall(t) -> chat(raw)
            has(t, "yozgat ağzı", "yozgat şivesi", "yozgatlı gibi") -> { Prefs.setDialect(c, "yozgat"); s.say("Hee tamam, bundan sonra bööle konuşacam gari") }
            has(t, "normal konuş", "düzgün konuş", "standart konuş", "istanbul türkçesi") -> { Prefs.setDialect(c, "standart"); s.say("Tamam, bundan sonra standart Türkçe konuşacağım") }
            has(t, "nasıl konuşursam", "otomatik konuş", "bana göre konuş") -> { Prefs.setDialect(c, "otomatik"); s.say("Tamam, sen nasıl konuşursan ben de öyle konuşacağım") }
            has(t, "el hareket") -> gestureMode(t)
            isWeather(t) -> weather(t)
            isFact(t) -> answer(t, raw)
            appSection(t) -> {}
            has(t, "mesaj") && has(t, "oku") -> readMessages()
            has(t, "alarm") -> setAlarm(t)
            has(t, "hatırlat", "takvime", "hatırlatıcı") -> addReminder(t)
            has(t, "youtube", "yutup") && !has(t, "televizyon") -> youtube(t)
            has(t, "spotify") -> spotify(t)
            isTv(t) -> tv(t)
            isNav(t) -> navAction(t)
            has(t, "gemini'ye sor", "gemini'a sor", "cemini'ye sor") -> askGemini(raw.replace(Regex("(?i)gemini'?(y?[ae])? sor|cemini'?ye sor"), "").trim())
            has(t, "gemini", "cemini") && isOpen(t) -> openPkg(GEMINI, "Gemini")
            has(t, "araştır", "claude'a sor", "klod'a sor") -> research(t, raw)
            has(t, "claude", "klod", "cloud'u") -> openClaude()
            has(t, "konuma başla", "navigasyonu başlat", "yola başla", "rotayı başlat", "konumu başlat") -> startNav()
            isMaps(t) -> maps(t)
            isMessage(t) -> composeMessage(t)
            shortcutCommand(t) -> {}
            screenSearch(t) -> {}
            screenTap(t) -> {}
            has(t, "youtube", "yutup") -> youtube(t)
            has(t, "spotify") -> spotify(t)
            isNews(t) -> news(t)
            isCall(t) -> call(t)
            has(t, "google", "internette", "internetten", "webde") || t.endsWith(" arat") -> google(t, raw, conf)
            inAppAction(t) -> {}
            isOpen(t) -> openApp(t)
            isQuestion(t) -> answer(t, raw)
            bareApp(t) -> {}
            // offline transcript was not clear enough: listen once more with Google's accurate recognizer
            quick -> s.listenCommand(null) { a, cf -> handle(a, cf, false) }
            // something said that is not a command: chat if Gemini is available, otherwise offer Google
            Prefs.geminiKey(c).isNotBlank() && t.split(" ").size <= 12 -> chat(raw)
            else -> s.ask("Bunu anlayamadım. Google'da arayayım mı?") { yes ->
                if (yes == true) webSearch(raw)
            }
        }
    }

    private fun launch(i: Intent, fallback: Intent? = null): Boolean {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { c.startActivity(i); true } catch (e: Exception) {
            if (fallback != null) launch(fallback) else { s.say("Bunu açamadım"); false }
        }
    }

    // ---------- apps ----------
    private val OPEN_VERBS = "aç|açar mısın|açsana|aç bakalım|başlat|çalıştır|gir|girer misin|gir bakalım|girelim|göster|getir"
    private fun isOpen(t: String) = Regex("(?<!\\p{L})($OPEN_VERBS)$").containsMatchIn(t)

    private fun openApp(t: String) {
        val name = t.replace(Regex("\\s*($OPEN_VERBS)$"), "")
            .replace(Regex("\\s*(uygulamasını|uygulamasına|uygulaması|oyununu|oyununa|oyunu|hesabıma|hesabımı|hesabına|sayfasına|sayfasını)$"), "")
            .replace(Regex("'[\\p{L}]*$"), "").trim()
        if (name.isEmpty()) { s.say("Hangi uygulamayı açayım?"); return }
        val hits = AppIndex.find(c, name)
        val top = hits.firstOrNull()
        when {
            top == null || top.score < 0.5 -> s.say("$name adında bir uygulama bulamadım")
            top.score >= 0.85 -> AppIndex.launch(c, top.pkg)
            else -> s.ask("${top.label} uygulamasından mı bahsediyorsun?") { yes ->
                when (yes) {
                    true -> AppIndex.launch(c, top.pkg)
                    false -> {
                        val second = hits.getOrNull(1)
                        if (second != null && second.score >= 0.5)
                            s.ask("${second.label} olabilir mi?") { y2 -> if (y2 == true) AppIndex.launch(c, second.pkg) else s.say("Tamam, açmıyorum") }
                        else s.say("Tamam, açmıyorum")
                    }
                    null -> s.say("Anlamadım, açmıyorum")
                }
            }
        }
    }

    private fun openPkg(pkg: String, label: String) {
        if (!AppIndex.launch(c, pkg)) s.say("$label yüklü değil")
    }

    /** a lone app name such as "instagram" */
    private fun bareApp(t: String): Boolean {
        if (t.split(" ").size > 3) return false
        val top = AppIndex.find(c, t.replace(Regex("'[\\p{L}]*$"), "")).firstOrNull() ?: return false
        if (top.score < 0.9) return false
        return AppIndex.launch(c, top.pkg)
    }

    // ---------- hand gestures on/off ----------
    private fun gestureMode(t: String) {
        val on = !has(t, "kapat", "kapa", "durdur")
        if (on && c.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            s.say("Kamera izni yok. Ayaz uygulamasından kamera iznini ver, sonra Ayaz'ı yeniden başlat."); return
        }
        Prefs.setGestures(c, on)
        if (!on) s.stopGestures()
        s.say(if (on) "El hareketleri açık. YouTube, Instagram, Facebook ve TikTok'ta elini yukarı kaldırınca sonraki, yana kaydırınca önceki videoya geçerim."
              else "El hareketlerini kapattım")
    }

    // ---------- open a section inside an app: reels, shorts, messages... ----------
    private data class Section(val app: String, val words: List<String>, val urls: List<String>, val pkg: String, val label: String)
    private val SECTIONS = listOf(
        Section("facebook", listOf("reels", "rils", "kısa video"), listOf("https://www.facebook.com/reel/", "https://www.facebook.com/watch/"), "com.facebook.katana", "Facebook Reels"),
        Section("facebook", listOf("video", "watch"), listOf("https://www.facebook.com/watch/"), "com.facebook.katana", "Facebook videolar"),
        Section("facebook", listOf("marketplace", "market"), listOf("https://www.facebook.com/marketplace/"), "com.facebook.katana", "Marketplace"),
        Section("instagram", listOf("reels", "rils", "kısa video", "video"), listOf("https://www.instagram.com/reels/"), "com.instagram.android", "Instagram Reels"),
        Section("instagram", listOf("mesaj", "dm", "direkt"), listOf("https://www.instagram.com/direct/inbox/"), "com.instagram.android", "Instagram mesajlar"),
        Section("youtube", listOf("shorts", "şort", "kısa video"), listOf("https://www.youtube.com/shorts"), "com.google.android.youtube", "YouTube Shorts"),
        Section("youtube", listOf("abonelik"), listOf("https://www.youtube.com/feed/subscriptions"), "com.google.android.youtube", "Abonelikler"),
        Section("tiktok", listOf("video", "keşfet"), listOf(), "com.zhiliaoapp.musically", "TikTok")
    )

    private fun appSection(t: String): Boolean {
        val sec = SECTIONS.firstOrNull { sc -> t.contains(sc.app) && sc.words.any { t.contains(it) } } ?: return false
        if (isMessage(t)) return false
        for (u in sec.urls) {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(u)).setPackage(sec.pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { c.startActivity(i); return true } catch (_: Exception) {}
        }
        if (AppIndex.launch(c, sec.pkg)) return true
        if (sec.pkg == "com.zhiliaoapp.musically" && AppIndex.launch(c, "com.ss.android.ugc.trill")) return true
        s.say("${sec.label} açılamadı"); return true
    }

    // ---------- close / back / home ----------
    private fun isNav(t: String) =
        Regex("(?<!\\p{L})(kapat|kapa|kapatır mısın|çık|çıkış yap|geri dön|geri git|geri|ana ekran(a dön|a git)?|son uygulamalar|bildirimleri aç|bildirimleri göster)$").containsMatchIn(t)

    private fun navAction(t: String) {
        val acc = AyazAccessibility.instance ?: run {
            s.say("Bunun için Erişilebilirlik izni gerekli. Ayaz uygulamasından aç."); return
        }
        val ok = when {
            has(t, "geri") -> acc.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            has(t, "son uygulamalar") -> acc.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS)
            has(t, "bildirim") -> acc.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            else -> acc.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME) // kapat, çık, ana ekran
        }
        if (!ok) s.say("Yapamadım")
    }

    // ---------- phone calls ----------
    private val CALL_VERB = Regex("\\s*(telefonla ara|telefon et|arama yap|ara|arar mısın|arasana|araya bağla)$")

    /** "… ara" always means a phone call; searching is "Google'da … ara", "internette ara" or a question */
    private fun isCall(t: String): Boolean {
        if (!CALL_VERB.containsMatchIn(t)) return false
        if (has(t, "google", "youtube", "internette", "internetten", "webde", "spotify", "haritada", "yakın")) return false
        return callName(t).isNotEmpty() || Regex("\\d{7,}").containsMatchIn(t.replace(" ", ""))
    }

    /** "babamı ara" -> "babam", "şeyma kızımı ara" -> "şeyma kızım", "burhan'ı ara" -> "burhan" */
    private fun callName(t: String) = t.replace(CALL_VERB, "")
        .replace(Regex("^(beni |bana )"), "")
        .replace(Regex("'?(y|n)?[ıiuü]$"), "").replace("'", "").trim()

    /** who to call: a number in the sentence, a saved "…numarası", or a person in contacts. Third value = how sure */
    private fun callTarget(t: String): Triple<String, String, Double>? {
        Regex("\\d{7,}").find(t.replace(" ", ""))?.let { return Triple(it.value, it.value, 1.0) }
        val name = callName(t)
        if (name.isEmpty()) return null
        // saved info: "babamın numarası = 0532…" answers "babamı ara"
        Shortcuts.all(c).entries.firstOrNull { (k, v) ->
            k.contains("numara") && v.count { it.isDigit() } >= 10 &&
                k.substringBefore(" numara").replace(Regex("'?n?[ıiuü]n$"), "") == name
        }?.let { return Triple(capFirst(name), it.value.filter { d -> d.isDigit() || d == '+' }, 1.0) }
        val ct = Contacts.find(c, name) ?: return null
        if (ct.score < 0.6) return null
        return Triple(ct.name, ct.number, ct.score)
    }

    private fun call(t: String) {
        val spokenName = callName(t)
        val (who, number, sure) = callTarget(t) ?: run { s.say("Rehberde ${capFirst(spokenName)} bulamadım"); return }
        // say it the way you said it: "Babam aranıyor"
        val label = if (spokenName.isNotEmpty() && !spokenName.any { it.isDigit() }) capFirst(spokenName) else who
        val dial = {
            val canCall = c.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
            if (!canCall) s.say("Arama izni yok, numarayı açtım, yeşil tuşa sen bas")
            else s.say("$label aranıyor")
            ui.postDelayed({ launch(Intent(if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$number"))) }, if (canCall) 900L else 0L)
        }
        // only ask when it could be someone else (two "kızım" in contacts, a half-matching name)
        if (sure >= 0.9) dial()
        else s.ask("$who mı aransın?") { yes -> if (yes == true) dial() else s.say("Tamam, aramıyorum") }
    }

    // ---------- short, sure answers ----------
    private val DIST_Q = Regex("^(?:buradan |benim bulunduğum yerden |bulunduğum yerden |(.+?)'?(?:[dt][ae]n) )?(.+?)(?:'?(?:y?[ae]))? (?:kaç km|kaç kilometre|ne kadar uzak|kaç saat|kaç saatte|ne kadar sürer)")

    /** clearly a fact question, even when phrased as "… göster" */
    private fun isFact(t: String) = has(t, "puan durumu", "kaç km", "kaç kilometre", "kaçta", "kaç metre", "kaç yaşında", "nüfusu",
        "başkenti", "fikstür", "maç sonucu", "maçı ne zaman", "kim kazandı", "kaç gol", "ne kadar uzak", "maçı hangi gün",
        "maç hangi gün", "maçı saat", "maç saat", "maçı ne zaman", "kaç kaç bitti", "skoru")

    private fun answer(t: String, raw: String) {
        val q = capFirst(raw.trim().trimEnd('?')) + "?"
        // distances are calculated, not looked up
        DIST_Q.find(t)?.let { m -> distance(m.groupValues[1].trim(), m.groupValues[2].trim(), q); return }
        if (Prefs.geminiKey(c).isBlank()) {
            // no key: ask the Gemini app on the phone and read its answer; without Gemini, read Google
            if (!geminiAppAnswer(raw, q)) googleAndRead(raw, q, noKey = true)
            return
        }
        s.overlay.thinking(q)
        Thread {
            val place = lastPlace()
            val a = try { Answers.ask(c, raw, place) } catch (e: Exception) { s.log("Cevap hatası: ${e.message}"); null }
            ui.post {
                if (a != null && a.sure) {
                    s.overlay.showAnswer(q, a.display)
                    s.say(a.spoken)
                } else {
                    s.overlay.dismiss()
                    if (a == null) {
                        s.log("Akıllı cevap alınamadı: ${Answers.lastError}")
                        if (!geminiAppAnswer(raw, q)) googleAndRead(raw, q, noKey = false)
                    } else googleAndRead(raw, q, noKey = false)
                }
            }
        }.start()
    }

    private val DAYS_TR = mapOf("pzt" to "Pazartesi", "sal" to "Salı", "çar" to "Çarşamba", "per" to "Perşembe", "cum" to "Cuma", "cmt" to "Cumartesi", "paz" to "Pazar")
    private val MONTHS_TR = listOf("Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık")

    /**
     * Opens Google, then reads the answer card on its screen when it is a match list
     * ("Galatasaray | Kasımpaşa | 9/10 Cum | 20:00") and says it.
     */
    private fun googleAndRead(raw: String, q: String, noKey: Boolean) {
        webSearch(raw)
        val acc = AyazAccessibility.instance ?: return
        ui.postDelayed({
            val segs = (acc.screenText()?.second ?: "").split(" | ").map { it.trim() }.filter { it.isNotEmpty() }
            val date = Regex("^(\\d{1,2})/(\\d{1,2})(?:\\s+(\\p{L}{3}))?(?:\\s+(\\d{1,2}:\\d{2}))?$")
            var spoken: String? = null; var shown: String? = null
            for ((i, sgm) in segs.withIndex()) {
                val m = date.find(sgm) ?: continue
                val time = m.groupValues[4].ifEmpty { segs.getOrNull(i + 1)?.takeIf { Regex("^\\d{1,2}:\\d{2}$").matches(it) } ?: "" }
                val teams = segs.subList(maxOf(0, i - 2), i).filter { it.any { ch -> ch.isLetter() } && it.length < 40 }
                if (teams.size < 2) continue
                val day = m.groupValues[1].toInt(); val mon = m.groupValues[2].toInt()
                val dayName = DAYS_TR[trLower(m.groupValues[3])] ?: ""
                val dateTxt = "$day ${MONTHS_TR.getOrElse(mon - 1) { "" }} $dayName".trim()
                spoken = "${teams[0]} ${teams[1]} maçı $dateTxt" + (if (time.isNotEmpty()) " saat $time" else "") + "."
                shown = "${teams[0]} – ${teams[1]}\n$dateTxt" + (if (time.isNotEmpty()) "\nSaat $time" else "")
                break
            }
            if (spoken == null) readTopAnswer(segs)?.let { (sp, sh) -> spoken = sp; shown = sh }
            if (spoken != null && shown != null) {
                s.overlay.showAnswer(q, shown!!); s.say(spoken!!)
            } else if (noKey && !Prefs.keyHintGiven(c)) {
                Prefs.setKeyHintGiven(c, true)
                s.say("Google'da açtım. Bu tür soruları kendim cevaplamam için Ayaz ekranındaki Akıllı cevaplar bölümüne ücretsiz anahtarı eklemen gerekiyor.")
            }
        }, 3500)
    }

    /**
     * Any other short answer Google shows at the top (AI overview, answer box, knowledge card):
     * the text right under the tab bar, until the "people also ask" / video sections.
     */
    private fun readTopAnswer(segs: List<String>): Pair<String, String>? {
        val tabs = setOf("Görseller", "Haberler", "Videolar", "Alışveriş", "Haritalar", "Kısa videolar", "Web", "Kitaplar", "Uçuşlar")
        val stop = Regex("(?i)(insanlar (şunları|bunları) da soruyor|people also ask|ilgili aramalar|diğer videolar|benzer aramalar|daha fazla göster|geri bildirim)")
        val skip = Regex("(?i)^(spor|tümü|ai modu|sponsorlu|reklam|paylaş|kaydet|daha fazla|tümünü göster|ana sayfa|ara|bildirimler|etkinlik|göster|·|›|>)$")
        var start = segs.take(30).indexOfLast { it in tabs } + 1
        val ai = segs.indexOfFirst { it.contains("Yapay Zeka Genel Bakışı") || it.contains("AI Overview") }
        if (ai >= 0) start = ai + 1
        if (start <= 0 || start >= segs.size) return null
        val sb = StringBuilder()
        for (sg in segs.drop(start)) {
            if (stop.containsMatchIn(sg)) break
            if (skip.matches(sg) || sg.length < 2 || sg.startsWith("http") || sg.contains("www.")) continue
            if (sb.isNotEmpty()) sb.append(sb.last().let { if (it == '.' || it == ':') " " else " · " })
            sb.append(sg)
            if (sb.length > 260) break
        }
        val text = sb.toString().trim()
        if (text.length < 12) return null
        val firstSentence = Regex("^(.{12,170}?[.!?])(\\s|$)").find(text)?.groupValues?.get(1) ?: text.take(170)
        return firstSentence.replace(" · ", ", ") to text.take(320)
    }

    /**
     * Sends the question to the Gemini app, presses send, waits until the answer stops
     * changing, then speaks it and shows it on Ayaz's own screen.
     */
    private fun geminiAppAnswer(raw: String, q: String): Boolean {
        val acc = AyazAccessibility.instance ?: return false
        if (!AppIndex.installed(c, GEMINI)) return false
        val question = capFirst(raw.trim())
        val share = Intent(Intent.ACTION_SEND).setType("text/plain").setPackage(GEMINI)
            .putExtra(Intent.EXTRA_TEXT, "Kısa ve net cevap ver, en fazla 2 cümle: $question").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { c.startActivity(share) } catch (e: Exception) { return false }
        s.overlay.thinking(q)
        val sendWords = listOf("Gönder", "Send", "İstem gönder", "Submit", "Gönder düğmesi")
        val noise = Regex("(?i)^(gemini|paylaş|kopyala|beğen|beğenme|yeniden oluştur|daha fazla|düzenle|gönder|send|share|copy|" +
            "sesli dinle|gemini hata yapabilir.*|gemini.*yanlış.*|kaynaklar|sources|yeni sohbet|menü|mikrofon|kamera|ekle|.*sor\\.\\.\\.?|" +
            "fast|hızlı|pro|düşünme|thinking|·)$")
        var last = ""; var same = 0; var tries = 0
        fun extract(): String {
            val segs = (acc.screenText()?.second ?: "").split(" | ").map { it.trim() }.filter { it.isNotEmpty() }
            // the answer is what comes after the last copy of the question on screen
            val qi = segs.indexOfLast { it.contains(question.take(20), ignoreCase = true) }
            return segs.drop(if (qi >= 0) qi + 1 else 0)
                .filter { !noise.matches(it) && it.length > 1 && !it.contains(question.take(20), ignoreCase = true) }
                .joinToString(" ").replace(Regex("\\s+"), " ").trim()
        }
        fun poll() {
            tries++
            val now = extract()
            if (now.isNotEmpty() && now == last) same++ else same = 0
            last = now
            when {
                same >= 2 && now.length >= 3 -> {          // stopped changing: the answer is complete
                    val spoken = Regex("^(.{3,220}?[.!?])(\\s|$)").find(now)?.groupValues?.get(1) ?: now.take(220)
                    s.overlay.showAnswer(q, now.take(400))
                    s.say(spoken)
                }
                tries > 20 -> { s.overlay.dismiss(); s.say("Gemini cevap vermedi, ekranda açık bıraktım") }
                else -> ui.postDelayed({ poll() }, 1500)
            }
        }
        ui.postDelayed({
            acc.findAndTap(sendWords, false) { _ -> ui.postDelayed({ poll() }, 2500) }
        }, 2500)
        return true
    }

    /** best-effort place name for "buradan" and local questions (no waiting for GPS) */
    private fun lastPlace(): String? {
        if (!Locator.allowed(c)) return null
        val lm = c.getSystemService(android.location.LocationManager::class.java)
        val l = try {
            @Suppress("MissingPermission")
            listOf("network", "gps", "passive").mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
        } catch (_: SecurityException) { null } ?: return null
        val name = Locator.placeName(c, l)
        return "%s (%.4f, %.4f)".format(java.util.Locale.US, name ?: "", l.latitude, l.longitude)
    }

    private fun distance(fromRaw: String, toRaw: String, q: String) {
        s.overlay.thinking(q)
        val toName = toRaw.replace("'", "").trim()
        val go = { fLat: Double, fLon: Double, fName: String ->
            Thread {
                val res = try {
                    val to = Weather.geocode(toName) ?: Weather.geocode(capFirst(toName.split(" ").last()))
                    if (to == null) null else Route.drive(fLat, fLon, to.first, to.second)?.let { r -> Triple(to.third, r.first, r.second) }
                } catch (e: Exception) { null }
                ui.post {
                    if (res == null) {
                        s.overlay.dismiss()
                        if (Prefs.geminiKey(c).isNotBlank()) answerViaGemini(q) else webSearch(q)
                    } else {
                        val km = if (res.second >= 10) "%.0f".format(res.second) else "%.1f".format(res.second).replace('.', ',')
                        val time = Route.duration(res.third)
                        s.overlay.showAnswer(q, "$km km\nArabayla yaklaşık $time\n$fName → ${res.first}")
                        s.say("${res.first}, ${ablative(fName)} yol ile $km kilometre, arabayla yaklaşık $time.")
                    }
                }
            }.start()
        }
        if (fromRaw.isNotEmpty() && fromRaw !in setOf("buradan", "burası")) {
            Thread {
                val f = try { Weather.geocode(capFirst(fromRaw.replace("'", ""))) } catch (e: Exception) { null }
                ui.post { if (f == null) { s.overlay.dismiss(); webSearch(q) } else go(f.first, f.second, f.third) }
            }.start()
        } else {
            Locator.get(c) { l ->
                if (l == null) { s.overlay.dismiss(); s.say(Locator.problem(c) ?: "Konumunu şu an alamadım"); return@get }
                Thread { val n = Locator.placeName(c, l) ?: "Bulunduğun yer"; ui.post { go(l.latitude, l.longitude, n) } }.start()
            }
        }
    }

    private fun answerViaGemini(q: String) {
        s.overlay.thinking(q)
        Thread {
            val a = try { Answers.ask(c, q, lastPlace()) } catch (e: Exception) { null }
            ui.post { if (a != null && a.sure) { s.overlay.showAnswer(q, a.display); s.say(a.spoken) } else { s.overlay.dismiss(); webSearch(q) } }
        }.start()
    }

    // ---------- small talk ----------
    private fun chat(raw: String) {
        val said = trLower(raw)
        Chat.remember("Kullanıcı", raw)
        Thread {
            val reply = Chat.ai(c, raw) ?: Chat.builtIn(c, said)
            Chat.remember("Ayaz", reply)
            ui.post { s.say(reply) }
        }.start()
    }

    // ---------- news ----------
    private fun isNews(t: String) = has(t, "haber") && !isMessage(t)

    private fun news(t: String) {
        val topic = t.replace(Regex("(son dakika|güncel|bugünkü|bugünün|en son|haberlerini|haberleri|haberler|haber|göster|aç|oku|getir|bana)"), " ")
            .replace(Regex("\\s+"), " ").trim()
        val url = if (topic.isEmpty()) "https://news.google.com/topstories?hl=tr&gl=TR&ceid=TR:tr"
                  else "https://news.google.com/search?q=${enc(topic)}&hl=tr&gl=TR&ceid=TR:tr"
        launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        s.say(if (topic.isEmpty()) "Son dakika haberlerini açtım" else "${capFirst(topic)} haberlerini açtım")
    }

    // ---------- questions go straight to Google ----------
    private val QWORDS = Regex("(?<!\\p{L})(hangi|hangisi|ne zaman|kaçta|kaçında|saat kaç|kaç|kim|kimin|kime|nerede|nereye|nereden|neresi|nasıl|neden|niye|niçin|ne kadar|nedir|kimdir|ne)(?!\\p{L})")

    private fun isQuestion(t: String) = t.contains("?") || has(t, "kaç km", "kaç kilometre", "puan durumu", "kaçta", "ne zaman", "kim kazandı", "skor") ||
        (QWORDS.containsMatchIn(t) && !isOpen(t) && !isMessage(t)) ||
        Regex("(?<!\\p{L})(nedir|kimdir|nerede|nereye|nasıl|ne zaman|kaç|hangi|neden|niye|ne kadar|mı|mi|mu|mü|mısın|misin)$").containsMatchIn(t) ||
        Regex("^(ne|kim|nerede|nasıl|neden|niye|kaç|hangi) ").containsMatchIn(t)

    // ---------- Gemini for general questions ----------
    private val GEMINI = "com.google.android.apps.bard"

    private fun askGemini(q: String) {
        val question = capFirst(q.trim())
        if (question.isEmpty()) { openPkg(GEMINI, "Gemini"); return }
        if (!AppIndex.installed(c, GEMINI)) {
            s.say("Gemini yüklü değil, Google'da arıyorum"); webSearch(question); return
        }
        val share = Intent(Intent.ACTION_SEND).setType("text/plain").setPackage(GEMINI)
            .putExtra(Intent.EXTRA_TEXT, question).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { c.startActivity(share) } catch (e: Exception) {
            // fallback: question on the clipboard, then open Gemini
            c.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Ayaz", question))
            AppIndex.launch(c, GEMINI)
            s.say("Sorunu panoya kopyaladım, Gemini'de yapıştırıp gönder")
        }
    }

    // ---------- weather ----------
    private fun isWeather(t: String) = has(t, "hava durumu", "hava nasıl", "havalar nasıl", "kaç derece", "hava kaç", "yağmur yağacak", "kar yağacak") ||
        (has(t, "hava") && has(t, "nasıl", "durum", "derece", "sıcak", "soğuk", "yağmur", "kar "))

    private fun weather(t: String) {
        val day = when { has(t, "öbür gün", "yarından sonra") -> 2; has(t, "yarın") -> 1; else -> 0 }
        val skip = setOf("yarın", "bugün", "burada", "orada", "dışarıda", "dışarı", "akşam", "sabah", "şu", "şimdi", "bu")
        val place = Regex("(\\p{L}+)'?[dt][ae] (?:yarın |bugün |şu an |şimdi )?hava").find(t)?.groupValues?.get(1)?.takeIf { it !in skip }
        val speak = { lat: Double, lon: Double, name: String? ->
            Thread {
                val r = try { Weather.report(lat, lon, name, day) } catch (e: Exception) { null }
                ui.post { s.say(r ?: "Hava durumunu alamadım, internet bağlantını kontrol et") }
            }.start()
        }
        if (place != null) {
            Thread {
                val g = try { Weather.geocode(capFirst(place)) } catch (e: Exception) { null }
                ui.post { if (g == null) s.say("${capFirst(place)} için hava durumunu bulamadım") else speak(g.first, g.second, g.third) }
            }.start()
        } else {
            Locator.get(c) { l ->
                if (l == null) { s.say((Locator.problem(c) ?: "Konumunu alamadım.") + " İstersen şehir söyle, örneğin İstanbul'da hava nasıl."); return@get }
                Thread { val n = Locator.placeName(c, l); ui.post { speak(l.latitude, l.longitude, n) } }.start()
            }
        }
    }

    // ---------- the user's own short info ----------
    private fun shortcutCommand(t: String): Boolean {
        val (name, value) = Shortcuts.find(c, t) ?: return false
        val digits = value.filter { it.isDigit() }
        val isUrl = value.startsWith("http") || (!value.contains(" ") && Regex("\\.[a-z]{2,}").containsMatchIn(value.lowercase()) && digits.length < 6)
        when {
            has(t, "kopyala") -> {
                c.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText(name, value.replace("|", "\n")))
                s.say("${capFirst(name)} kopyalandı, istediğin yere yapıştırabilirsin")
            }
            has(t, " ne", "nedir", "söyle", "oku", "kaç") || t.endsWith(" ne") -> s.say("${capFirst(name)}: ${value.replace("|", ", ")}")
            isUrl -> launch(Intent(Intent.ACTION_VIEW, Uri.parse(if (value.startsWith("http")) value else "https://$value")))
            digits.length >= 10 && w("(ara|arar mısın|arasana)").containsMatchIn(t) && !value.uppercase().startsWith("TR") ->
                s.ask("$name aransın mı?") { y -> if (y == true) launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits"))) }
            else -> {
                c.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText(name, value.replace("|", "\n")))
                s.say("${capFirst(name)} panoya kopyalandı")
            }
        }
        return true
    }

    // ---------- doing things on the current screen ----------
    private fun accOrSay(): AyazAccessibility? = AyazAccessibility.instance ?: run {
        s.say("Bunun için Erişilebilirlik izni gerekli. Ayaz uygulamasından aç."); null
    }

    /** "umut'u" -> "umut", "ayarlara" -> "ayarlar" (only the last word) */
    private fun baseForm(p: String): String {
        val words = p.split(" ").toMutableList()
        val last = words.last()
        words[words.lastIndex] = if (last.contains("'")) last.substringBefore("'")
            else last.replace(Regex("(y[ıiuü]|y[ae]|n[ıiuü]|n[ae]|[ıiuü]|[ae])$"), "").takeIf { it.length >= 3 } ?: last
        return words.joinToString(" ")
    }

    private fun targetsFor(p: String) = listOf(p.replace("'", ""), baseForm(p)).distinct()

    /** "bu sayfada umut ara", "burada kırmızı ayakkabı ara" */
    private fun screenSearch(t: String): Boolean {
        val m = Regex("^(?:burada|bu sayfada|bu uygulamada|uygulamada|sayfada|içeride) (.+?) (?:diye )?(ara|arat)$").find(t) ?: return false
        val acc = accOrSay() ?: return true
        acc.typeSearch(m.groupValues[1]) { ok -> if (!ok) s.say("Bu ekranda arama kutusu bulamadım") }
        return true
    }

    /** "ayarlar'a tıkla", "umut'u bul", "kaydet butonuna bas" */
    private fun screenTap(t: String): Boolean {
        val tap = Regex("^(?:ekranda |burada |sayfada |bu sayfada )?(.+?) (?:butonuna |düğmesine |yazısına |simgesine )?(tıkla|bas|dokun|seç)$").find(t)
        val find = Regex("^(?:ekranda |burada |sayfada |bu sayfada |listede )?(.+?) (bul|bul ve aç|bulup aç)$").find(t)
        val m = tap ?: find ?: return false
        val phrase = m.groupValues[1].trim()
        if (phrase.isEmpty()) return false
        if (find != null && has(phrase, "yakın")) {   // "en yakın eczaneyi bul" is a map search
            maps("haritada ${baseForm(phrase)}"); return true
        }
        val acc = accOrSay() ?: return true
        // "instagram'da umut'u bul": open the app and use its search
        val first = phrase.split(" ").first()
        if (find != null && Regex("'?[dt][ae]$").containsMatchIn(first) && phrase.contains(" ")) {
            val hit = AppIndex.find(c, first.substringBefore("'").replace(Regex("[dt][ae]$"), "")).firstOrNull()
            if (hit != null && hit.score >= 0.9 && AppIndex.launch(c, hit.pkg)) {
                val q = baseForm(phrase.substringAfter(" "))
                ui.postDelayed({ acc.typeSearch(q) { ok -> if (!ok) s.say("${hit.label} içinde arama kutusunu bulamadım") } }, 2500)
                return true
            }
        }
        acc.findAndTap(targetsFor(phrase), scroll = find != null) { ok -> if (!ok) s.say("Ekranda ${baseForm(phrase)} bulamadım") }
        return true
    }

    /** "instagram profilime gir", "whatsapp'ta ayarlara git", "youtube kitaplığımı aç" */
    private val SECTION_WORDS = linkedMapOf(
        "profil" to listOf("Profil", "Profile", "Profilim", "Hesap", "Siz", "You"),
        "hesab" to listOf("Hesap", "Hesabım", "Profil", "Account"),
        "mesaj" to listOf("Mesajlar", "Messages", "Sohbetler", "Chats", "Direct", "Gelen Kutusu"),
        "sohbet" to listOf("Sohbetler", "Chats", "Mesajlar"),
        "bildirim" to listOf("Bildirimler", "Notifications", "Etkinlik", "Activity"),
        "ayar" to listOf("Ayarlar", "Settings"),
        "keşfet" to listOf("Keşfet", "Explore", "Ara", "Search"),
        "ana sayfa" to listOf("Ana Sayfa", "Home", "Akış"),
        "anasayfa" to listOf("Ana Sayfa", "Home", "Akış"),
        "reels" to listOf("Reels"),
        "shorts" to listOf("Shorts"),
        "abonelik" to listOf("Abonelikler", "Subscriptions"),
        "kitaplı" to listOf("Kitaplık", "Library", "Siz", "You"),
        "kaydedil" to listOf("Kaydedilenler", "Saved"),
        "arkadaş" to listOf("Arkadaşlar", "Friends"),
        "durum" to listOf("Güncellemeler", "Durum", "Updates"),
        "aramalar" to listOf("Aramalar", "Calls"),
        "sepet" to listOf("Sepet", "Sepetim", "Cart"),
        "sipariş" to listOf("Siparişlerim", "Siparişler", "Orders")
    )
    private val CONNECT_WORDS = setOf("benim", "bana", "uygulamasında", "uygulamasından", "uygulamasını", "içinde", "içindeki",
        "sayfasına", "sayfasını", "sayfamı", "sayfama", "kısmına", "bölümüne", "sekmesine", "sekmesini", "bölümünü")

    private fun inAppAction(t: String): Boolean {
        val verb = Regex("\\s*($OPEN_VERBS|git|geç|bak)$")
        if (!verb.containsMatchIn(t)) return false
        val tokens = t.replace(verb, "").split(" ").filter { it.isNotBlank() }
        if (tokens.size < 2) return false
        // the whole phrase is an app name ("mobile legends'ı aç"): leave it to openApp
        val whole = tokens.joinToString(" ").replace(Regex("'[\\p{L}]*$"), "")
        if ((AppIndex.find(c, whole).firstOrNull()?.score ?: 0.0) >= 0.85) return false
        var app: AppHit? = null
        var appIdx = -1
        for ((i, w) in tokens.withIndex()) {
            val base = w.substringBefore("'").replace(Regex("(t[ae]|d[ae]|n[ae]|n[ıiuü]n)$"), "").ifBlank { w }
            if (base.length < 3) continue
            val hit = AppIndex.find(c, base).firstOrNull()
            if (hit != null && hit.score >= 0.9) { app = hit; appIdx = i; break }
        }
        val a = app ?: return false
        val rest = tokens.filterIndexed { i, _ -> i != appIdx }.filter { it !in CONNECT_WORDS }
        if (rest.isEmpty()) return false
        if (rest.all { trLower(a.label).contains(baseForm(it)) }) return false    // words are part of the app's own name
        val phrase = rest.joinToString(" ")
        val key = SECTION_WORDS.keys.firstOrNull { phrase.contains(it) }
        val targets = key?.let { SECTION_WORDS[it] } ?: targetsFor(phrase)
        if (!AppIndex.launch(c, a.pkg)) return false
        val acc = AyazAccessibility.instance ?: run {
            s.say("${a.label} açıldı. İçinde işlem yapabilmem için Erişilebilirlik izni gerekli."); return true
        }
        ui.postDelayed({
            acc.findAndTap(targets, scroll = key == null) { ok -> if (!ok) s.say("${a.label} içinde ${baseForm(phrase)} bulamadım") }
        }, 2500)
        return true
    }

    // ---------- TV through the Mi Remote app ----------
    private val MI_REMOTE = "com.duokan.phone.remotecontroller"

    private fun miRemote(t0: String) {
        if (!AppIndex.installed(c, MI_REMOTE)) { s.say("Bu telefonda kızılötesi kumanda ya da Mi Kumanda uygulaması bulunamadı"); return }
        val acc = accOrSay() ?: return
        var t = TurkishTime.numWords(t0)
        for ((k, v) in ORDINALS) t = t.replace(k, "$v.")
        val ch = Regex("(\\d{1,4})\\s*(?:\\.|'?[ıiuü]?n?c[ıiuü]|inci|ıncı|uncu|üncü)?\\s*kanal").find(t)?.groupValues?.get(1)
            ?: Regex("kanal\\s*(\\d{1,4})").find(t)?.groupValues?.get(1)
        val presses: List<List<String>> = when {
            ch != null -> ch.map { listOf(it.toString()) }
            has(t, "sessize al", "sesi kapat", "sesini kapat") -> listOf(listOf("Sessiz", "Mute"))
            Regex("ses(ini|i)? (kıs|azalt|düşür)").containsMatchIn(t) -> List(3) { listOf("Ses -", "Ses azalt", "Vol-", "Volume down", "Ses kısma") }
            Regex("ses(ini|i)? (aç|artır|yükselt)").containsMatchIn(t) -> List(3) { listOf("Ses +", "Ses artır", "Vol+", "Volume up", "Ses yükseltme") }
            has(t, "önceki kanal", "kanal geri", "kanalı geri", "kanal aşağı") -> listOf(listOf("Kanal -", "CH-", "Channel down"))
            has(t, "kanal") -> listOf(listOf("Kanal +", "CH+", "Channel up"))
            else -> listOf(listOf("Güç", "Power", "Aç/Kapat"))
        }
        AppIndex.launch(c, MI_REMOTE)
        fun pressAll(i: Int) {
            if (i >= presses.size) return
            acc.findAndTap(presses[i], false) { ok ->
                if (!ok) s.say("Kumandada düğmeyi bulamadım") else ui.postDelayed({ pressAll(i + 1) }, 450)
            }
        }
        ui.postDelayed({
            // open the Samsung remote if the device list is showing, then press the buttons
            acc.findAndTap(listOf("Samsung", "Samsung TV", "Televizyon", "TV"), false) { _ -> ui.postDelayed({ pressAll(0) }, 1500) }
        }, 2500)
    }

    // ---------- claude ----------
    private fun openClaude() = openPkg("com.anthropic.claude", "Claude uygulaması")

    private fun research(t: String, raw: String) {
        val q = t.replace(Regex("(claude'a|klod'a) sor|araştır(ır mısın|sana)?|bunu|hakkında"), " ")
            .replace(Regex("\\s+"), " ").trim()
        if (q.isEmpty()) { s.listenCommand("Ne araştırayım?") { a, _ -> research("araştır $a", a) }; return }
        val cm = c.getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("Ayaz", capFirst(q)))
        if (AppIndex.launch(c, "com.anthropic.claude"))
            s.say("Sorunu panoya kopyaladım. Claude'da yazı alanına basılı tutup yapıştır.")
        else s.say("Claude uygulaması yüklü değil")
    }

    // ---------- maps ----------
    private fun isMaps(t: String) = has(t, "yol tarifi", "navigasyon", "götür", "nasıl giderim", "haritada", "haritalarda", "konumunu aç", "konumu aç", "konuma git")

    private fun maps(t: String) {
        if (has(t, "konum") && (has(t, "whatsapp") || has(t, "attığı", "gönderdiği", "yolladığı", "paylaştığı", "atılan", "gelen"))) {
            whatsappLocation(t); return
        }
        val dest = t.replace(Regex("yol tarifi(ni)?( ver| al| aç| göster)?|navigasyon(u)?( aç| başlat)?|nasıl giderim|beni|götür|haritada|haritalarda|göster|konumunu aç|konumu aç|konuma git|git|gidelim"), " ")
            .replace(Regex("'(y|n)?[ae](?!\\p{L})"), "")
            .replace(Regex("\\s+"), " ").trim()
        if (dest.isEmpty()) { s.listenCommand("Nereye gidiyoruz?") { a, _ -> maps("${trLower(a)} yol tarifi") }; return }
        lastDestination = dest
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=${enc(dest)}"))
            .setPackage("com.google.android.apps.maps")
        val fb = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=${enc(dest)}"))
        if (launch(i, fb)) speakEta(capFirst(dest), pressDirections = false)
    }

    private val ui = android.os.Handler(android.os.Looper.getMainLooper())

    /** "Umut'un WhatsApp'tan gönderdiği konumu aç": open the chat, tap the newest location */
    private fun whatsappLocation(t: String) {
        val acc = AyazAccessibility.instance ?: run {
            s.say("Bunun için Erişilebilirlik izni gerekli. Ayaz uygulamasından aç."); return
        }
        // the person is every word before "attığı / gönderdiği…": "şeyma kızımın", "mehmet kardeşin"
        val tokens = t.split(" ").filter { it.isNotBlank() && !isPlatformWord(it) && it !in FILLER }
        val verb = Regex("^(attığı|attiği|gönderdiği|yolladığı|paylaştığı|atılan|gelen|son|konum)")
        val gen = Regex("'?(n)?[ıiuü]n$")
        var nameWords = tokens.takeWhile { !verb.containsMatchIn(it) }
        if (nameWords.isEmpty()) {
            // "konumu aç umut'un" or other orders: take the words with a genitive ending
            nameWords = tokens.filter { gen.containsMatchIn(it) && !verb.containsMatchIn(it) }
        }
        if (nameWords.isEmpty()) { s.listenCommand("Kimin gönderdiği konumu açayım?") { a, _ -> whatsappLocation("${trLower(a)} gönderdiği konum") }; return }
        val name = nameWords.takeLast(3).mapIndexed { i, w ->
            if (i == nameWords.takeLast(3).lastIndex) w.replace(gen, "") else w
        }.joinToString(" ").replace("'", "")
        val contact = Contacts.find(c, name) ?: run { s.say("Rehberde $name adında birini bulamadım"); return }
        val go = {
            lastDestination = null
            val url = "https://api.whatsapp.com/send?phone=${Contacts.waNumber(contact.number)}"
            if (launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.whatsapp"), Intent(Intent.ACTION_VIEW, Uri.parse(url)))) {
                s.say("${contact.name} sohbetinde konumu arıyorum")
                // the chat can take a moment to load: try a few times
                val attempt = object : (Int) -> Unit {
                    override fun invoke(n: Int) {
                        if (acc.clickLastLocation()) {
                            ui.postDelayed({
                                val pkg = acc.screenText()?.first ?: ""
                                if (!pkg.contains("maps")) acc.continueToMaps()
                                speakEta("${contact.name} kişisinin konumu", pressDirections = true)
                            }, 1500)
                        } else if (n < 3) ui.postDelayed({ this.invoke(n + 1) }, 1500)
                        else s.say("Sohbette görünen bir konum bulamadım. Konum daha yukarıdaysa sohbeti biraz kaydırıp tekrar söyle.")
                    }
                }
                ui.postDelayed({ attempt(0) }, 2000)
            }
        }
        if (contact.score < 0.8) s.ask("${contact.name} kişisinin konumu mu?") { y -> if (y == true) go() else s.say("Tamam") }
        else go()
    }

    // ---------- distance and time, read from the Google Maps screen ----------
    private val DUR = Regex("(?:(\\d+)\\s*sa(?:at)?\\.?\\s*)?(\\d+)\\s*dk|(\\d+)\\s*sa(?:at)?(?!\\p{L})")
    private val DIST = Regex("(\\d+(?:[.,]\\d+)?)\\s*km(?!\\p{L})|(\\d+)\\s*m(?!\\p{L})")

    private fun speakEta(label: String, pressDirections: Boolean) {
        val acc = AyazAccessibility.instance ?: run {
            s.say("$label açıldı. Mesafeyi söyleyebilmem için Erişilebilirlik izni gerekli."); return
        }
        val read: (Int) -> Unit = object : (Int) -> Unit {
            override fun invoke(tries: Int) {
                val (pkg, text) = acc.screenText() ?: ("" to "")
                val d = DUR.find(text)
                val k = DIST.find(text)
                if (pkg.contains("maps") && d != null && k != null) {
                    val h = d.groupValues[1].toIntOrNull() ?: d.groupValues[3].toIntOrNull() ?: 0
                    val m = d.groupValues[2].toIntOrNull() ?: 0
                    val time = listOfNotNull(if (h > 0) "$h saat" else null, if (m > 0) "$m dakika" else null).joinToString(" ")
                    val dist = if (k.groupValues[1].isNotEmpty()) "${k.groupValues[1].replace('.', ',')} kilometre" else "${k.groupValues[2]} metre"
                    s.say("$label: $dist, arabayla yaklaşık $time. Başlatmak için Ayaz, konuma başla de.")
                } else if (tries < 4) {
                    ui.postDelayed({ this.invoke(tries + 1) }, 1500)
                } else s.say("$label açıldı. Başlatmak için Ayaz, konuma başla de.")
            }
        }
        if (pressDirections) {
            ui.postDelayed({
                acc.clickText(listOf("Yol tarifi", "Directions"))
                ui.postDelayed({ read(0) }, 2500)
            }, 2500)
        } else ui.postDelayed({ read(0) }, 3000)
    }

    private fun startNav() {
        val d = lastDestination
        if (d == null) {
            val acc = AyazAccessibility.instance ?: run { s.say("Önce gideceğin yeri söylemelisin"); return }
            if (acc.clickText(listOf("Başlat", "Start"))) { s.say("Navigasyonu başlattım"); return }
            if (acc.clickText(listOf("Yol tarifi", "Directions", "Rota"))) {
                ui.postDelayed({
                    if (acc.clickText(listOf("Başlat", "Start"))) s.say("Navigasyonu başlattım")
                    else s.say("Başlat tuşunu bulamadım, ekrandan sen bas")
                }, 2500)
                return
            }
            s.say("Önce gideceğin yeri söylemelisin"); return
        }
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${enc(d)}")).setPackage("com.google.android.apps.maps")
        if (launch(i)) s.say("Navigasyonu başlattım")
    }

    // ---------- messages ----------
    private fun isMessage(t: String): Boolean {
        if (Regex("(?<!\\p{L})(yaz|diye yaz|mesaj at|mesaj gönder|mesaj yolla|de ki)$").containsMatchIn(t) ||
            has(t, " mesaj at ", " mesaj gönder ")) return true
        // "babama benim ibanımı gönder", "mevcut konumumu umut'a at", "mehmet'in numarasını babama yolla"
        if (!Regex("(?<!\\p{L})(gönder|yolla|paylaş|at|ilet)$").containsMatchIn(t)) return false
        if (Shortcuts.find(c, t) == null && !Shortcuts.mentionsLocation(t) && !t.contains("numaras")) return false
        return t.split(" ").any { DATIVE.containsMatchIn(it) && !isPlatformWord(it) && (Contacts.find(c, it.replace(DATIVE, ""))?.score ?: 0.0) >= 0.75 }
    }

    private val NUMBER_OF = Regex("(\\p{L}+(?: \\p{L}+)?)'?n?[ıiuü]n numaras[ıi](n[ıi])?")

    /** shortcut names -> values, "mehmet'in numarası" -> number from contacts, then current location if asked */
    private fun resolveMessage(text: String, go: (String) -> Unit) {
        var b = Shortcuts.expand(c, text)
        NUMBER_OF.findAll(b).toList().reversed().forEach { m ->
            Contacts.find(c, m.groupValues[1])?.let { ct -> b = b.replaceRange(m.range, "${ct.name}: ${ct.number}") }
        }
        if (!Shortcuts.mentionsLocation(b)) { go(b); return }
        Locator.get(c) { l ->
            if (l == null) { s.say(Locator.problem(c) ?: "Konumunu şu an alamadım, birazdan tekrar dene."); return@get }
            val link = "Konumum: " + Locator.mapsLink(l)
            val loc = Regex("(mevcut |şu anki |şimdiki |bulunduğum )?konum\\p{L}*|nerede olduğumu")
            go(if (loc.replace(b, "").isBlank()) link else loc.replace(b, link))
        }
    }

    private val DATIVE = Regex("'?(y|n)?[ae]$")
    private val FILLER = setOf("tan", "dan", "ten", "den", "üzerinden", "ile", "olarak", "şunu", "şöyle")

    /** offline speech can write "WhatsApp" as "vatsaptan", "what sap", "otsap"… */
    private fun isPlatformWord(w: String): Boolean {
        val x = w.replace(Regex("'.*$"), "")
        if (x.contains("whatsapp") || x.contains("sap") || x.contains("telegram") || x == "sms") return true
        return x.length >= 5 && similarity(x.take(8), "whatsapp") >= 0.6
    }

    private fun composeMessage(t: String) {
        val sms = has(t, "sms", "kısa mesaj")
        val tg = has(t, "telegram")
        var body = t
            .replace(Regex("\\s*(whats ?app|vatsap|watsap)'?[\\p{L}]*( üzerinden| ile| olarak)?"), "")
            .replace(Regex("\\s*(sms|kısa mesaj)'?[\\p{L}]*( ile| olarak)?"), "")
            .replace(Regex("\\s*telegram'?[\\p{L}]*( üzerinden| ile)?"), "")
            .replace(Regex("\\s+(diye yaz|diye gönder|yaz|mesaj at|mesaj gönder|mesaj yolla|de ki|gönder|yolla|paylaş|ilet|at)$"), "")
            .trim()
        val tokens = body.split(" ").filter { it.isNotBlank() }.toMutableList()
        if (tokens.isEmpty()) { s.say("Kime yazayım?"); return }
        var nameIdx = -1
        var nameCount = 1
        for (i in 0 until minOf(4, tokens.size)) {
            if (!DATIVE.containsMatchIn(tokens[i]) || isPlatformWord(tokens[i])) continue
            val one = tokens[i].replace(DATIVE, "")
            val two = if (i > 0 && !isPlatformWord(tokens[i - 1]) && tokens[i - 1] !in FILLER) tokens[i - 1] + " " + one else null
            if (two != null && (Contacts.find(c, two)?.score ?: 0.0) >= 0.85) { nameIdx = i; nameCount = 2; break }
            if ((Contacts.find(c, one)?.score ?: 0.0) >= 0.75) { nameIdx = i; break }
        }
        if (nameIdx < 0) nameIdx = tokens.indexOfFirst { DATIVE.containsMatchIn(it) && !isPlatformWord(it) }.takeIf { it >= 0 } ?: 0
        val name = (if (nameCount == 2) tokens[nameIdx - 1] + " " else "") + tokens[nameIdx].replace(DATIVE, "")
        body = tokens.drop(nameIdx + 1).filterIndexed { i, w -> !isPlatformWord(w) && !(i == 0 && w in FILLER) }
            .joinToString(" ")
            .replace(Regex("^(mesaj at|mesaj gönder|mesaj yolla)\\s*"), "").trim()
        if (body.isEmpty()) {
            // "mevcut konumumu babama gönder": the content came before the person
            body = tokens.take(nameIdx - (nameCount - 1)).filter { !isPlatformWord(it) && it !in FILLER }.joinToString(" ")
        }

        val contact = Contacts.find(c, name)
        if (contact == null) {
            if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
                s.say("Rehber izni yok. Ayaz uygulamasından rehber iznini aç.")
            else s.say("Rehberde $name adında birini bulamadım")
            return
        }
        val go = { text: String -> resolveMessage(text) { full -> prepare(if (sms) "sms" else if (tg) "tg" else "wa", contact, full) } }
        val withText = { if (body.isEmpty()) s.listenCommand("${contact.name} kişisine ne yazayım?") { a, _ -> go(a) } else go(body) }
        if (contact.score < 0.8) s.ask("${contact.name} kişisine mi yazayım?") { yes -> if (yes == true) withText() else s.say("Tamam, iptal ettim") }
        else withText()
    }

    private fun prepare(type: String, contact: Contact, rawText: String) {
        // a "|" in a saved info means separate messages (IBAN, then the name)
        val parts = rawText.split("|").map { capFirst(it.trim()) }.filter { it.isNotEmpty() }
        if (parts.isEmpty()) return
        val text = parts.first()
        val more = if (type == "wa") parts.drop(1) else emptyList()
        if (type != "wa" && parts.size > 1) return prepare(type, contact, parts.joinToString("\n"))
        draft = Draft(type, contact.name, contact.number, text, more)
        if (type == "wa") {
            val url = "https://api.whatsapp.com/send?phone=${Contacts.waNumber(contact.number)}&text=${enc(text)}"
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.whatsapp")
            if (!launch(i, Intent(Intent.ACTION_VIEW, Uri.parse(url)))) return
        } else if (type == "tg") {
            val url = "tg://msg?to=%2B${Contacts.waNumber(contact.number)}&text=${enc(text)}"
            if (!launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))) return
            draft = null
            s.say("${contact.name} için Telegram'da yazdım: $text. Gönder tuşuna sen bas.")
            return
        } else {
            launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${contact.number}")).putExtra("sms_body", text))
        }
        val extra = if (more.isNotEmpty()) " Ardından ${more.size} ayrı mesaj daha göndereceğim." else ""
        s.say("${contact.name} için yazdım: ${spoken(text)}.$extra Göndermek için Ayaz, gönder de.")
    }

    /** long numbers are not read digit by digit */
    private fun spoken(t: String) = if (t.count { it.isDigit() } >= 12) "numarayı" else t

    private fun sendDraft() {
        val d = draft ?: return
        if (d.type == "wa") {
            val acc = AyazAccessibility.instance
            if (acc == null) { s.say("Erişilebilirlik izni kapalı. Gönder tuşuna sen bas."); return }
            if (!acc.clickWhatsAppSend()) { s.say("Gönder tuşunu bulamadım. WhatsApp sohbeti açık mı?"); return }
            draft = null
            sendRest(acc, d.more, 0)
        } else {
            if (c.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                s.say("SMS gönderme izni yok"); return
            }
            try {
                val sm = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
                sm.sendMultipartTextMessage(d.number, null, sm.divideMessage(d.text), null, null)
                draft = null
                s.say("SMS gönderildi")
            } catch (e: Exception) { s.say("SMS gönderilemedi") }
        }
    }

    private fun sendRest(acc: AyazAccessibility, rest: List<String>, i: Int) {
        if (i >= rest.size) { s.say("Gönderildi"); return }
        ui.postDelayed({
            if (acc.setWhatsAppText(rest[i])) {
                ui.postDelayed({
                    if (acc.clickWhatsAppSend()) sendRest(acc, rest, i + 1)
                    else s.say("İkinci mesajı yazdım ama gönderemedim, gönder tuşuna sen bas")
                }, 500)
            } else s.say("İlk mesaj gitti, ikinci mesajı yazamadım")
        }, 700)
    }

    private fun fixDraft(t: String) {
        val d = draft ?: return
        var text = d.text
        val m1 = Regex("(.+?) yerine (.+?)(?: yaz| yap| koy| olsun)?$").find(t)
        val m2 = Regex("(.+?) kelimesini (.+?)(?: olarak)?(?: düzelt| yap| yaz| değiştir)$").find(t)
        val m3 = Regex("(.+?)'?[ıiuü]? (.+?) (?:olarak düzelt|ile değiştir|diye düzelt)$").find(t)
        when {
            t.contains("son kelimeyi sil") -> text = text.substringBeforeLast(" ", "")
            m2 != null -> text = replaceWord(text, m2.groupValues[1], m2.groupValues[2]) ?: run { notFound(m2.groupValues[1]); return }
            m1 != null -> text = replaceWord(text, m1.groupValues[1], m1.groupValues[2]) ?: run { notFound(m1.groupValues[1]); return }
            m3 != null -> text = replaceWord(text, m3.groupValues[1], m3.groupValues[2]) ?: run { notFound(m3.groupValues[1]); return }
            else -> { s.say("Nasıl düzelteyim? Örneğin: geliyorum yerine geldim yaz."); return }
        }
        d.text = text
        val ok = d.type == "wa" && AyazAccessibility.instance?.setWhatsAppText(text) == true
        if (!ok && d.type == "wa") {
            s.say("Mesaj alanını değiştiremedim. Erişilebilirlik izni açık mı?"); return
        }
        if (d.type == "sms") launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${d.number}")).putExtra("sms_body", text))
        s.say("Düzelttim: $text")
    }

    private fun notFound(word: String) {
        s.say("$word kelimesini mesajda bulamadım. Mesaj şu: ${draft?.text}")
    }

    private fun replaceWord(text: String, old: String, new: String): String? {
        val o = old.trim().removeSuffix("'").trim()
        val r = Regex("(?<!\\p{L})" + Regex.escape(o) + "(?!\\p{L})", RegexOption.IGNORE_CASE)
        if (!r.containsMatchIn(text)) return null
        return r.replaceFirst(text, new.trim())
    }

    private fun readMessages() {
        if (!NotifListener.connected) {
            s.say("Bildirim erişimi kapalı. Ayaz uygulamasından bildirim erişimini aç."); return
        }
        val list = NotifListener.unread()
        if (list.isEmpty()) { s.say("Yeni mesajın yok"); return }
        val lines = list.takeLast(5).map { "${it.sender}, ${it.app} üzerinden yazdı: ${it.text}" }
        if (list.size > 5) s.say("${list.size} yeni mesaj var. Son beşini okuyorum.")
        s.sayQueue(lines)
        NotifListener.markRead()
    }

    // ---------- alarm & calendar ----------
    private fun setAlarm(t: String) {
        val time = TurkishTime.parseTime(t) ?: run {
            s.listenCommand("Alarmı saat kaça kurayım?") { a, _ -> setAlarm("alarm ${trLower(a)}") }; return
        }
        val days = TurkishTime.repeatDays(t)
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, time.first)
            .putExtra(AlarmClock.EXTRA_MINUTES, time.second)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Ayaz")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (days.isNotEmpty()) i.putExtra(AlarmClock.EXTRA_DAYS, ArrayList(days))
        val hm = "%02d:%02d".format(time.first, time.second)
        if (launch(i)) s.say(if (days.isEmpty()) "$hm için alarm kurdum" else "${TurkishTime.dayNames(days)} $hm için alarm kurdum")
    }

    private fun addReminder(t: String) {
        val cal = TurkishTime.parseDate(t) ?: run {
            s.listenCommand("Ne zaman hatırlatayım?") { a, _ -> addReminder("$t ${trLower(a)}") }; return
        }
        val title = TurkishTime.reminderTitle(t)
        if (c.checkSelfPermission(Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            val i = Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, title)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, cal.timeInMillis)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, cal.timeInMillis + 30 * 60_000)
            launch(i); s.say("Takvim izni olmadığı için ekleme ekranını açtım"); return
        }
        val calId = calendarId() ?: run { s.say("Telefonda yazılabilir bir takvim bulamadım"); return }
        try {
            val ev = ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, calId)
                put(CalendarContract.Events.TITLE, title)
                put(CalendarContract.Events.DTSTART, cal.timeInMillis)
                put(CalendarContract.Events.DTEND, cal.timeInMillis + 30 * 60_000)
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
                put(CalendarContract.Events.HAS_ALARM, 1)
            }
            val uri = c.contentResolver.insert(CalendarContract.Events.CONTENT_URI, ev) ?: throw Exception("insert")
            val eventId = uri.lastPathSegment!!.toLong()
            for (min in listOf(0, 15)) {
                c.contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, ContentValues().apply {
                    put(CalendarContract.Reminders.EVENT_ID, eventId)
                    put(CalendarContract.Reminders.MINUTES, min)
                    put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
                })
            }
            val f = SimpleDateFormat("d MMMM EEEE HH:mm", TR).format(cal.time)
            s.say("$f için \"$title\" hatırlatmasını takvime ekledim")
        } catch (e: Exception) { s.say("Takvime ekleyemedim") }
    }

    private fun calendarId(): Long? {
        if (c.checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) return null
        c.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.IS_PRIMARY, CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL),
            "${CalendarContract.Calendars.VISIBLE} = 1", null, null
        )?.use { cur ->
            var fallback: Long? = null
            while (cur.moveToNext()) {
                val id = cur.getLong(0)
                val primary = cur.getInt(1) == 1
                val level = cur.getInt(2)
                if (level < CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR) continue
                if (primary) return id
                if (fallback == null) fallback = id
            }
            return fallback
        }
        return null
    }

    // ---------- TV ----------
    private fun isTv(t: String) = has(t, "televizyon", "tv'", " tv", "kanal", "samsung") ||
        Regex("ses(ini|i)? (kıs|azalt|düşür|aç|artır|yükselt)").containsMatchIn(t) || has(t, "sessize al")

    private val ORDINALS = mapOf("birinci" to 1, "ikinci" to 2, "üçüncü" to 3, "dördüncü" to 4, "beşinci" to 5,
        "altıncı" to 6, "yedinci" to 7, "sekizinci" to 8, "dokuzuncu" to 9, "onuncu" to 10)

    private fun tv(t0: String) {
        if (!TvRemote.available(c) || Prefs.tvViaApp(c)) { miRemote(t0); return }
        var t = TurkishTime.numWords(t0)
        for ((k, v) in ORDINALS) t = t.replace(k, "$v.")
        val ch = Regex("(\\d{1,4})\\s*(?:\\.|'?[ıiuü]?n?c[ıiuü]|inci|ıncı|uncu|üncü)?\\s*kanal").find(t)?.groupValues?.get(1)
            ?: Regex("kanal\\s*(\\d{1,4})").find(t)?.groupValues?.get(1)
        val times = Regex("(\\d)\\s*(kere|kez)").find(t)?.groupValues?.get(1)?.toInt() ?: 3
        when {
            ch != null -> { TvRemote.send(c, TvRemote.channelCodes(ch.toInt()), 400); s.say("$ch. kanal") }
            has(t, "sessize al", "sesi kapat", "sesini kapat") -> TvRemote.send(c, listOf(TvRemote.MUTE))
            Regex("ses(ini|i)? (kıs|azalt|düşür)").containsMatchIn(t) -> TvRemote.send(c, List(times) { TvRemote.VOL_DOWN })
            Regex("ses(ini|i)? (aç|artır|yükselt)").containsMatchIn(t) -> TvRemote.send(c, List(times) { TvRemote.VOL_UP })
            has(t, "önceki kanal", "kanal geri", "kanalı geri", "kanal aşağı") -> TvRemote.send(c, listOf(TvRemote.CH_DOWN))
            has(t, "kanal") -> TvRemote.send(c, listOf(TvRemote.CH_UP))
            has(t, "kaynak") -> TvRemote.send(c, listOf(TvRemote.SOURCE))
            has(t, "aç", "kapat") -> TvRemote.send(c, listOf(TvRemote.POWER))
            else -> s.say("Televizyona ne yapayım?")
        }
    }

    // ---------- search ----------
    private fun strip(t: String, platform: String) = t.replace(Regex(platform), " ")
        .replace(Regex("(?<!\\p{L})(aç|ara|arat|oynat|izle|çal|göster|bul|başlat)$"), "")
        .replace(Regex("\\s+"), " ").trim()

    private fun youtube(t: String) {
        val q = strip(t, "(you ?tube|yutup)'?[\\p{L}]*")
        if (q.isEmpty()) { openPkg("com.google.android.youtube", "YouTube"); return }
        val i = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q)
        launch(i, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${enc(q)}")))
    }

    private fun spotify(t: String) {
        val q = strip(t, "spotify'?[\\p{L}]*")
        if (q.isEmpty()) { openPkg("com.spotify.music", "Spotify"); return }
        launch(Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${enc(q)}")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com/search/${enc(q)}")))
    }

    private fun google(t: String, raw: String, conf: Float) {
        val q = strip(t.replace(Regex("(?<!\\p{L})(internette|internetten|webde)(?!\\p{L})"), " ")
            .replace(Regex("\\s*(arama yap|aramasını yap|araması yap|ara bakalım|araştır)$"), ""), "google'?[\\p{L}]*")
        if (q.isEmpty()) { s.listenCommand("Ne arayayım?") { a, cf -> google("google ${trLower(a)} ara", a, cf) }; return }
        if (conf > 0f && conf < 0.4f) {
            s.ask("\"$q\" mı demek istedin?") { yes ->
                when (yes) {
                    true -> webSearch(q)
                    false -> s.listenCommand("Tekrar söyler misin?") { a, _ -> webSearch(a) }
                    null -> s.say("Anlamadım, aramadım")
                }
            }
        } else webSearch(q)
    }

    private fun webSearch(q: String) {
        val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)
        launch(i, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${enc(q)}")))
    }
}
