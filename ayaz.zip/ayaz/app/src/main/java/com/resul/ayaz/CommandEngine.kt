package com.resul.ayaz

import android.Manifest
import android.app.SearchManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.telephony.SmsManager
import java.text.SimpleDateFormat
import java.util.TimeZone

class CommandEngine(private val s: AyazService) {

    data class Draft(val type: String, val name: String, val number: String, var text: String)

    private var draft: Draft? = null
    private var lastDestination: String? = null
    private val c: Context get() = s

    private fun has(t: String, vararg words: String) = words.any { t.contains(it) }
    private fun enc(x: String) = Uri.encode(x)
    private fun w(word: String) = Regex("(?<!\\p{L})$word(?!\\p{L})")

    fun handle(raw: String, conf: Float) {
        val t = trLower(raw).removePrefix("ayaz ").trim()
        s.log("Sen: $raw")
        when {
            t.isEmpty() -> s.say("Seni duyamadım")
            draft != null && w("(gönder|yolla)").containsMatchIn(t) && t.split(" ").size <= 3 -> sendDraft()
            draft != null && (has(t, "düzelt", " yerine ", "kelimesini", "son kelimeyi sil", "değiştir")) -> fixDraft(t)
            draft != null && w("(iptal|vazgeç)").containsMatchIn(t) -> { draft = null; s.say("Mesajı iptal ettim") }
            has(t, "güncelleme") -> Updater.check(c, interactive = true) { s.say(it) }
            has(t, "mesaj") && has(t, "oku") -> readMessages()
            has(t, "alarm") -> setAlarm(t)
            has(t, "hatırlat", "takvime", "hatırlatıcı") -> addReminder(t)
            has(t, "youtube", "yutup") && !has(t, "televizyon") -> youtube(t)
            has(t, "spotify") -> spotify(t)
            isTv(t) -> tv(t)
            has(t, "araştır", "claude'a sor", "klod'a sor") -> research(t, raw)
            has(t, "claude", "klod", "cloud'u") -> openClaude()
            has(t, "konuma başla", "navigasyonu başlat", "yola başla", "rotayı başlat", "konumu başlat") -> startNav()
            isMaps(t) -> maps(t)
            isMessage(t) -> composeMessage(t)
            has(t, "youtube", "yutup") -> youtube(t)
            has(t, "spotify") -> spotify(t)
            has(t, "google") || t.endsWith(" ara") || t.endsWith(" arat") -> google(t, raw, conf)
            isOpen(t) -> openApp(t)
            else -> s.ask("Bunu anlayamadım. Google'da \"$raw\" diye arayayım mı?") { yes ->
                if (yes == true) webSearch(raw)
            }
        }
    }

    private fun launch(i: Intent, fallback: Intent? = null): Boolean {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { c.startActivity(i); true } catch (e: Exception) {
            if (fallback != null) launch(fallback) else { s.say("Bunu açamadım"); false }
        }
    }

    // ---------- apps ----------
    private fun isOpen(t: String) = Regex("(?<!\\p{L})(aç|açar mısın|açsana|başlat|çalıştır)$").containsMatchIn(t)

    private fun openApp(t: String) {
        val name = t.replace(Regex("\\s*(uygulamasını|uygulaması|oyununu|oyunu)?\\s*(aç|açar mısın|açsana|başlat|çalıştır)$"), "")
            .replace(Regex("'[\\p{L}]*$"), "").trim()
        if (name.isEmpty()) { s.say("Hangi uygulamayı açayım?"); return }
        val hits = AppIndex.find(c, name)
        val top = hits.firstOrNull()
        when {
            top == null || top.score < 0.5 -> s.say("$name adında bir uygulama bulamadım")
            top.score >= 0.85 -> AppIndex.launch(c, top.pkg)
            else -> s.ask("${top.label} uygulamasından mı bahsediyorsun?") { yes ->
                when (yes) {
                    true -> AppIndex.launch(c, top.pkg)
                    false -> {
                        val second = hits.getOrNull(1)
                        if (second != null && second.score >= 0.5)
                            s.ask("${second.label} olabilir mi?") { y2 -> if (y2 == true) AppIndex.launch(c, second.pkg) else s.say("Tamam, açmıyorum") }
                        else s.say("Tamam, açmıyorum")
                    }
                    null -> s.say("Anlamadım, açmıyorum")
                }
            }
        }
    }

    private fun openPkg(pkg: String, label: String) {
        if (!AppIndex.launch(c, pkg)) s.say("$label yüklü değil")
    }

    // ---------- claude ----------
    private fun openClaude() = openPkg("com.anthropic.claude", "Claude uygulaması")

    private fun research(t: String, raw: String) {
        val q = t.replace(Regex("(claude'a|klod'a) sor|araştır(ır mısın|sana)?|bunu|hakkında"), " ")
            .replace(Regex("\\s+"), " ").trim()
        if (q.isEmpty()) { s.listenCommand("Ne araştırayım?") { a, _ -> research("araştır $a", a) }; return }
        val cm = c.getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("Ayaz", capFirst(q)))
        if (AppIndex.launch(c, "com.anthropic.claude"))
            s.say("Sorunu panoya kopyaladım. Claude'da yazı alanına basılı tutup yapıştır.")
        else s.say("Claude uygulaması yüklü değil")
    }

    // ---------- maps ----------
    private fun isMaps(t: String) = has(t, "yol tarifi", "navigasyon", "götür", "nasıl giderim", "haritada", "haritalarda", "konumunu aç", "konumu aç", "konuma git")

    private fun maps(t: String) {
        if (has(t, "whatsapp", "vatsap") || (has(t, "konum") && has(t, "attığı", "gönderdiği", "yolladığı"))) {
            s.say("WhatsApp'tan gelen konumu açma özelliği bir sonraki sürümde gelecek.")
            return
        }
        val dest = t.replace(Regex("yol tarifi(ni)?( ver| al| aç| göster)?|navigasyon(u)?( aç| başlat)?|nasıl giderim|beni|götür|haritada|haritalarda|göster|konumunu aç|konumu aç|konuma git|git|gidelim"), " ")
            .replace(Regex("'(y|n)?[ae](?!\\p{L})"), "")
            .replace(Regex("\\s+"), " ").trim()
        if (dest.isEmpty()) { s.listenCommand("Nereye gidiyoruz?") { a, _ -> maps("${trLower(a)} yol tarifi") }; return }
        lastDestination = dest
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=${enc(dest)}"))
            .setPackage("com.google.android.apps.maps")
        val fb = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=${enc(dest)}"))
        if (launch(i, fb)) s.say("${capFirst(dest)} için yol tarifini açtım. Başlatmak için Ayaz, konuma başla de.")
    }

    private fun startNav() {
        val d = lastDestination ?: run { s.say("Önce gideceğin yeri söylemelisin"); return }
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${enc(d)}")).setPackage("com.google.android.apps.maps")
        if (launch(i)) s.say("Navigasyonu başlattım")
    }

    // ---------- messages ----------
    private fun isMessage(t: String) =
        Regex("(?<!\\p{L})(yaz|diye yaz|mesaj at|mesaj gönder|mesaj yolla|de ki)$").containsMatchIn(t) ||
            has(t, " mesaj at ", " mesaj gönder ")

    private val DATIVE = Regex("'?(y|n)?[ae]$")

    private fun composeMessage(t: String) {
        val sms = has(t, "sms", "kısa mesaj")
        var body = t
            .replace(Regex("\\s*(whats ?app|vatsap|watsap)'?[\\p{L}]*( üzerinden| ile| olarak)?"), "")
            .replace(Regex("\\s*(sms|kısa mesaj)'?[\\p{L}]*( ile| olarak)?"), "")
            .replace(Regex("\\s+(diye yaz|diye gönder|yaz|mesaj at|mesaj gönder|mesaj yolla|de ki)$"), "")
            .trim()
        val tokens = body.split(" ").filter { it.isNotBlank() }.toMutableList()
        if (tokens.isEmpty()) { s.say("Kime yazayım?"); return }
        val nameCount = when {
            DATIVE.containsMatchIn(tokens[0]) -> 1
            tokens.size > 1 && DATIVE.containsMatchIn(tokens[1]) -> 2
            else -> 1
        }
        val nameRaw = tokens.take(nameCount).joinToString(" ")
        val name = nameRaw.replace(DATIVE, "")
        body = tokens.drop(nameCount).joinToString(" ")
            .replace(Regex("^(mesaj at|mesaj gönder|mesaj yolla)\\s*"), "").trim()

        val contact = Contacts.find(c, name)
        if (contact == null) {
            if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
                s.say("Rehber izni yok. Ayaz uygulamasından rehber iznini aç.")
            else s.say("Rehberde $name adında birini bulamadım")
            return
        }
        val go = { text: String -> prepare(if (sms) "sms" else "wa", contact, text) }
        val withText = { if (body.isEmpty()) s.listenCommand("${contact.name} kişisine ne yazayım?") { a, _ -> go(a) } else go(body) }
        if (contact.score < 0.8) s.ask("${contact.name} kişisine mi yazayım?") { yes -> if (yes == true) withText() else s.say("Tamam, iptal ettim") }
        else withText()
    }

    private fun prepare(type: String, contact: Contact, rawText: String) {
        val text = capFirst(rawText.trim())
        draft = Draft(type, contact.name, contact.number, text)
        if (type == "wa") {
            val url = "https://api.whatsapp.com/send?phone=${Contacts.waNumber(contact.number)}&text=${enc(text)}"
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.whatsapp")
            if (!launch(i, Intent(Intent.ACTION_VIEW, Uri.parse(url)))) return
        } else {
            launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${contact.number}")).putExtra("sms_body", text))
        }
        s.say("${contact.name} için yazdım: $text. Göndermek için Ayaz, gönder de.")
    }

    private fun sendDraft() {
        val d = draft ?: return
        if (d.type == "wa") {
            val acc = AyazAccessibility.instance
            if (acc == null) { s.say("Erişilebilirlik izni kapalı. Gönder tuşuna sen bas."); return }
            if (acc.clickWhatsAppSend()) { draft = null; s.say("Gönderildi") }
            else s.say("Gönder tuşunu bulamadım. WhatsApp sohbeti açık mı?")
        } else {
            if (c.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                s.say("SMS gönderme izni yok"); return
            }
            try {
                val sm = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
                sm.sendMultipartTextMessage(d.number, null, sm.divideMessage(d.text), null, null)
                draft = null
                s.say("SMS gönderildi")
            } catch (e: Exception) { s.say("SMS gönderilemedi") }
        }
    }

    private fun fixDraft(t: String) {
        val d = draft ?: return
        var text = d.text
        val m1 = Regex("(.+?) yerine (.+?)(?: yaz| yap| koy| olsun)?$").find(t)
        val m2 = Regex("(.+?) kelimesini (.+?)(?: olarak)?(?: düzelt| yap| yaz| değiştir)$").find(t)
        val m3 = Regex("(.+?)'?[ıiuü]? (.+?) (?:olarak düzelt|ile değiştir|diye düzelt)$").find(t)
        when {
            t.contains("son kelimeyi sil") -> text = text.substringBeforeLast(" ", "")
            m2 != null -> text = replaceWord(text, m2.groupValues[1], m2.groupValues[2]) ?: run { notFound(m2.groupValues[1]); return }
            m1 != null -> text = replaceWord(text, m1.groupValues[1], m1.groupValues[2]) ?: run { notFound(m1.groupValues[1]); return }
            m3 != null -> text = replaceWord(text, m3.groupValues[1], m3.groupValues[2]) ?: run { notFound(m3.groupValues[1]); return }
            else -> { s.say("Nasıl düzelteyim? Örneğin: geliyorum yerine geldim yaz."); return }
        }
        d.text = text
        val ok = d.type == "wa" && AyazAccessibility.instance?.setWhatsAppText(text) == true
        if (!ok && d.type == "wa") {
            s.say("Mesaj alanını değiştiremedim. Erişilebilirlik izni açık mı?"); return
        }
        if (d.type == "sms") launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${d.number}")).putExtra("sms_body", text))
        s.say("Düzelttim: $text")
    }

    private fun notFound(word: String) {
        s.say("$word kelimesini mesajda bulamadım. Mesaj şu: ${draft?.text}")
    }

    private fun replaceWord(text: String, old: String, new: String): String? {
        val o = old.trim().removeSuffix("'").trim()
        val r = Regex("(?<!\\p{L})" + Regex.escape(o) + "(?!\\p{L})", RegexOption.IGNORE_CASE)
        if (!r.containsMatchIn(text)) return null
        return r.replaceFirst(text, new.trim())
    }

    private fun readMessages() {
        if (!NotifListener.connected) {
            s.say("Bildirim erişimi kapalı. Ayaz uygulamasından bildirim erişimini aç."); return
        }
        val list = NotifListener.unread()
        if (list.isEmpty()) { s.say("Yeni mesajın yok"); return }
        val lines = list.takeLast(5).map { "${it.sender}, ${it.app} üzerinden yazdı: ${it.text}" }
        if (list.size > 5) s.say("${list.size} yeni mesaj var. Son beşini okuyorum.")
        s.sayQueue(lines)
        NotifListener.markRead()
    }

    // ---------- alarm & calendar ----------
    private fun setAlarm(t: String) {
        val time = TurkishTime.parseTime(t) ?: run {
            s.listenCommand("Alarmı saat kaça kurayım?") { a, _ -> setAlarm("alarm ${trLower(a)}") }; return
        }
        val days = TurkishTime.repeatDays(t)
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, time.first)
            .putExtra(AlarmClock.EXTRA_MINUTES, time.second)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Ayaz")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (days.isNotEmpty()) i.putExtra(AlarmClock.EXTRA_DAYS, ArrayList(days))
        val hm = "%02d:%02d".format(time.first, time.second)
        if (launch(i)) s.say(if (days.isEmpty()) "$hm için alarm kurdum" else "${TurkishTime.dayNames(days)} $hm için alarm kurdum")
    }

    private fun addReminder(t: String) {
        val cal = TurkishTime.parseDate(t) ?: run {
            s.listenCommand("Ne zaman hatırlatayım?") { a, _ -> addReminder("$t ${trLower(a)}") }; return
        }
        val title = TurkishTime.reminderTitle(t)
        if (c.checkSelfPermission(Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            val i = Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, title)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, cal.timeInMillis)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, cal.timeInMillis + 30 * 60_000)
            launch(i); s.say("Takvim izni olmadığı için ekleme ekranını açtım"); return
        }
        val calId = calendarId() ?: run { s.say("Telefonda yazılabilir bir takvim bulamadım"); return }
        try {
            val ev = ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, calId)
                put(CalendarContract.Events.TITLE, title)
                put(CalendarContract.Events.DTSTART, cal.timeInMillis)
                put(CalendarContract.Events.DTEND, cal.timeInMillis + 30 * 60_000)
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
                put(CalendarContract.Events.HAS_ALARM, 1)
            }
            val uri = c.contentResolver.insert(CalendarContract.Events.CONTENT_URI, ev) ?: throw Exception("insert")
            val eventId = uri.lastPathSegment!!.toLong()
            for (min in listOf(0, 15)) {
                c.contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, ContentValues().apply {
                    put(CalendarContract.Reminders.EVENT_ID, eventId)
                    put(CalendarContract.Reminders.MINUTES, min)
                    put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
                })
            }
            val f = SimpleDateFormat("d MMMM EEEE HH:mm", TR).format(cal.time)
            s.say("$f için \"$title\" hatırlatmasını takvime ekledim")
        } catch (e: Exception) { s.say("Takvime ekleyemedim") }
    }

    private fun calendarId(): Long? {
        if (c.checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) return null
        c.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.IS_PRIMARY, CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL),
            "${CalendarContract.Calendars.VISIBLE} = 1", null, null
        )?.use { cur ->
            var fallback: Long? = null
            while (cur.moveToNext()) {
                val id = cur.getLong(0)
                val primary = cur.getInt(1) == 1
                val level = cur.getInt(2)
                if (level < CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR) continue
                if (primary) return id
                if (fallback == null) fallback = id
            }
            return fallback
        }
        return null
    }

    // ---------- TV ----------
    private fun isTv(t: String) = has(t, "televizyon", "tv'", " tv", "kanal") ||
        Regex("ses(ini|i)? (kıs|azalt|düşür|aç|artır|yükselt)").containsMatchIn(t) || has(t, "sessize al")

    private val ORDINALS = mapOf("birinci" to 1, "ikinci" to 2, "üçüncü" to 3, "dördüncü" to 4, "beşinci" to 5,
        "altıncı" to 6, "yedinci" to 7, "sekizinci" to 8, "dokuzuncu" to 9, "onuncu" to 10)

    private fun tv(t0: String) {
        if (!TvRemote.available(c)) { s.say("Bu telefonda kızılötesi kumanda bulunamadı"); return }
        var t = TurkishTime.numWords(t0)
        for ((k, v) in ORDINALS) t = t.replace(k, "$v.")
        val ch = Regex("(\\d{1,4})\\s*(?:\\.|'?[ıiuü]?n?c[ıiuü]|inci|ıncı|uncu|üncü)?\\s*kanal").find(t)?.groupValues?.get(1)
            ?: Regex("kanal\\s*(\\d{1,4})").find(t)?.groupValues?.get(1)
        val times = Regex("(\\d)\\s*(kere|kez)").find(t)?.groupValues?.get(1)?.toInt() ?: 3
        when {
            ch != null -> { TvRemote.send(c, TvRemote.channelCodes(ch.toInt()), 400); s.say("$ch. kanal") }
            has(t, "sessize al", "sesi kapat", "sesini kapat") -> TvRemote.send(c, listOf(TvRemote.MUTE))
            Regex("ses(ini|i)? (kıs|azalt|düşür)").containsMatchIn(t) -> TvRemote.send(c, List(times) { TvRemote.VOL_DOWN })
            Regex("ses(ini|i)? (aç|artır|yükselt)").containsMatchIn(t) -> TvRemote.send(c, List(times) { TvRemote.VOL_UP })
            has(t, "önceki kanal", "kanal geri", "kanalı geri", "kanal aşağı") -> TvRemote.send(c, listOf(TvRemote.CH_DOWN))
            has(t, "kanal") -> TvRemote.send(c, listOf(TvRemote.CH_UP))
            has(t, "kaynak") -> TvRemote.send(c, listOf(TvRemote.SOURCE))
            has(t, "aç", "kapat") -> TvRemote.send(c, listOf(TvRemote.POWER))
            else -> s.say("Televizyona ne yapayım?")
        }
    }

    // ---------- search ----------
    private fun strip(t: String, platform: String) = t.replace(Regex(platform), " ")
        .replace(Regex("(?<!\\p{L})(aç|ara|arat|oynat|izle|çal|göster|bul|başlat)$"), "")
        .replace(Regex("\\s+"), " ").trim()

    private fun youtube(t: String) {
        val q = strip(t, "(you ?tube|yutup)'?[\\p{L}]*")
        if (q.isEmpty()) { openPkg("com.google.android.youtube", "YouTube"); return }
        val i = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q)
        launch(i, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${enc(q)}")))
    }

    private fun spotify(t: String) {
        val q = strip(t, "spotify'?[\\p{L}]*")
        if (q.isEmpty()) { openPkg("com.spotify.music", "Spotify"); return }
        launch(Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${enc(q)}")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com/search/${enc(q)}")))
    }

    private fun google(t: String, raw: String, conf: Float) {
        val q = strip(t, "google'?[\\p{L}]*")
        if (q.isEmpty()) { s.listenCommand("Ne arayayım?") { a, cf -> google("google ${trLower(a)} ara", a, cf) }; return }
        if (conf in 0f..0.6f) {
            s.ask("\"$q\" mı demek istedin?") { yes ->
                when (yes) {
                    true -> webSearch(q)
                    false -> s.listenCommand("Tekrar söyler misin?") { a, _ -> webSearch(a) }
                    null -> s.say("Anlamadım, aramadım")
                }
            }
        } else webSearch(q)
    }

    private fun webSearch(q: String) {
        val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)
        launch(i, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${enc(q)}")))
    }
}
