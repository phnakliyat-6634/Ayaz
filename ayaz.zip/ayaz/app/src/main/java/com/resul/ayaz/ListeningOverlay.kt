package com.resul.ayaz

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Transparent "listening" effect in the middle of the screen: a glowing ring with
 * drifting light particles and a voice wave below. Touches pass straight through.
 */
class ListeningOverlay(private val c: Context) {
    private val wm = c.getSystemService(WindowManager::class.java)
    private var view: OrbView? = null
    private var anim: ValueAnimator? = null
    private var pinned = false
    private val h = android.os.Handler(android.os.Looper.getMainLooper())
    private var params: WindowManager.LayoutParams? = null

    fun show() {
        if (!Prefs.overlay(c) || !Settings.canDrawOverlays(c)) return
        if (view == null) {
            val v = OrbView(c)
            val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY   // minSdk 26
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.CENTER }
            try { wm.addView(v, lp); view = v; params = lp } catch (_: Exception) { return }
        }
        // a new listening session: back to the listening look
        pinned = false
        h.removeCallbacksAndMessages(null)
        view?.let { it.answerTitle = ""; it.answerText = null; it.thinking = false }
        setTouchable(false)
        fadeTo(1f)
    }

    /** "looking it up" state: the orb stays up while the answer is being fetched */
    fun thinking(question: String) {
        show()
        pinned = true
        view?.let { it.thinking = true; it.caption = question }
    }

    /** shows a short answer under a smaller orb; tap anywhere or wait to close */
    fun showAnswer(question: String, answer: String) {
        if (view == null) show()
        val v = view ?: return
        pinned = true
        v.thinking = false
        v.answerTitle = question
        v.answerText = answer
        v.caption = ""
        setTouchable(true)
        v.setOnClickListener { dismiss() }
        fadeTo(1f)
        h.removeCallbacksAndMessages(null)
        h.postDelayed({ dismiss() }, (7000L + answer.length * 70L).coerceAtMost(25000L))
    }

    fun dismiss() { pinned = false; h.removeCallbacksAndMessages(null); hide() }

    private fun setTouchable(on: Boolean) {
        val v = view ?: return; val lp = params ?: return
        lp.flags = if (on) lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                   else lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
    }

    fun hide() {
        if (pinned) return
        val v = view ?: return
        fadeTo(0f) {
            try { wm.removeView(v) } catch (_: Exception) {}
            if (view === v) view = null
        }
    }

    fun level(rmsDb: Float) { view?.level = ((rmsDb + 2f) / 12f).coerceIn(0f, 1f) }
    fun text(t: String) { view?.caption = t }

    private fun fadeTo(target: Float, end: (() -> Unit)? = null) {
        val v = view ?: return
        anim?.cancel()
        anim = ValueAnimator.ofFloat(v.appear, target).apply {
            duration = if (target > 0f) 280 else 420
            interpolator = DecelerateInterpolator()
            addUpdateListener { v.appear = it.animatedValue as Float; v.invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) { if (target == 0f) end?.invoke() }
            })
            start()
        }
    }

    private class OrbView(c: Context) : View(c) {
        var appear = 0f
        var level = 0f
        var caption = ""
        var thinking = false
        var answerTitle = ""
        var answerText: String? = null
        private var smooth = 0f
        private val wave = FloatArray(16)
        private val t0 = System.nanoTime()
        private var shockAt = -1f
        private var lastAppear = 0f

        private class Dot(var r: Float, var a: Float, val size: Float, val phase: Float)
        private val dots = List(320) {
            Dot(sqrt(Random.nextFloat()), Random.nextFloat() * 6.283f, 1.1f + Random.nextFloat() * 2.1f, Random.nextFloat() * 6.283f)
        }

        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER }
        private val oval = android.graphics.RectF()
        private val title = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD)
        }

        private fun argb(a: Float, r: Int, g: Int, b: Int) = Color.argb((255 * a.coerceIn(0f, 1f)).toInt(), r, g, b)
        private fun circleStroke(cv: Canvas, x: Float, y: Float, rad: Float, w: Float, col: Int) {
            stroke.strokeWidth = w; stroke.color = col; cv.drawCircle(x, y, rad, stroke)
        }
        private fun arc(cv: Canvas, cx: Float, cy: Float, rad: Float, fromRad: Float, sweepRad: Float, w: Float, col: Int) {
            oval.set(cx - rad, cy - rad, cx + rad, cy + rad)
            stroke.strokeWidth = w; stroke.color = col
            cv.drawArc(oval, Math.toDegrees(fromRad.toDouble()).toFloat(), Math.toDegrees(sweepRad.toDouble()).toFloat(), false, stroke)
        }

        override fun onDraw(cv: Canvas) {
            if (appear <= 0.01f) { lastAppear = appear; return }
            val t = (System.nanoTime() - t0) / 1e9f
            if (lastAppear < 0.05f && appear >= 0.05f) shockAt = t       // shockwave each time Ayaz wakes
            lastAppear = appear
            smooth += (level - smooth) * 0.25f
            for (i in 0 until wave.size - 1) wave[i] = wave[i + 1]
            wave[wave.size - 1] = smooth

            val A = appear
            val W = width.toFloat(); val H = height.toFloat()
            val ans = answerText != null
            if (thinking) level = 0.25f + 0.2f * sin(t * 6f)      // a gentle pulse while looking it up
            val cx = W / 2f; val cy = H * (if (ans) 0.22f else 0.42f)
            val base = min(W, H) * (if (ans) 0.17f else 0.30f)
            val R = base * (0.85f + 0.15f * A) * (1f + smooth * 0.07f + 0.012f * sin(t * 2.2f))

            // see-through navy veil
            fill.shader = RadialGradient(cx, cy, H * 0.75f, intArrayOf(argb(0.62f * A, 8, 30, 80), argb(0.42f * A, 4, 12, 38)), null, Shader.TileMode.CLAMP)
            cv.drawRect(0f, 0f, W, H, fill); fill.shader = null

            // shockwave
            if (shockAt >= 0f) {
                val k = (t - shockAt) / 0.9f
                if (k < 1f) circleStroke(cv, cx, cy, R * (1f + k * 1.2f), 3f * (1f - k) + 1f, argb((1f - k) * 0.8f * A, 255, 214, 74))
            }

            // inner glow
            fill.shader = RadialGradient(cx, cy, R * 1.25f, intArrayOf(argb(0.30f * A, 60, 170, 255), argb(0.14f * A, 20, 90, 200), Color.TRANSPARENT),
                floatArrayOf(0f, 0.7f, 1f), Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, R * 1.25f, fill); fill.shader = null

            // tick ring
            stroke.strokeWidth = 1.5f; stroke.color = argb(0.45f * A, 120, 210, 255)
            for (i in 0 until 72) {
                val a = i * 0.0873f + t * 0.05f; val r1 = R * 1.30f; val r2 = r1 + if (i % 6 == 0) R * 0.06f else R * 0.025f
                cv.drawLine(cx + cos(a) * r1, cy + sin(a) * r1, cx + cos(a) * r2, cy + sin(a) * r2, stroke)
            }
            // HUD dashes, counter-rotating
            for (i in 0 until 12) arc(cv, cx, cy, R * 1.16f, i * 0.5236f - t * 0.35f, 0.30f, R * 0.018f, argb(0.55f * A, 90, 220, 255))
            circleStroke(cv, cx, cy, R * 1.08f, 1.5f, argb(0.25f * A, 120, 210, 255))
            circleStroke(cv, cx, cy, R * 0.55f, 1.5f, argb(0.25f * A, 120, 210, 255))

            // vortex particles flowing into the core
            val flow = 0.04f + smooth * 0.25f
            val dens = resources.displayMetrics.density
            for (d in dots) {
                d.r -= flow * 0.016f * (0.4f + d.r)
                if (d.r < 0.08f) { d.r = 1f; d.a = Random.nextFloat() * 6.283f }
                d.a += (0.25f / (0.25f + d.r)) * 0.016f * (1f + smooth * 2f)
                val rr = d.r * R * 0.95f
                val tw = 0.55f + 0.45f * sin(t * 2.5f + d.phase)
                fill.color = argb(0.85f * A * tw * min(1f, d.r * 4f), 120, 235, 255)
                cv.drawCircle(cx + cos(d.a) * rr, cy + sin(d.a) * rr, d.size * dens * 0.6f * (0.6f + d.r * 0.6f), fill)
            }

            // core that beats with your voice
            val cr = R * (0.20f + smooth * 0.16f + 0.02f * sin(t * 4f))
            fill.shader = RadialGradient(cx, cy, cr * 2.2f, intArrayOf(argb(0.95f * A, 255, 255, 255), argb(0.65f * A, 150, 235, 255), Color.TRANSPARENT),
                floatArrayOf(0f, 0.25f, 1f), Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, cr * 2.2f, fill); fill.shader = null

            // AYAZ in the centre: letters appear one by one, glow, a light sweeps across
            run {
                val word = "AYAZ"
                val fs = R * 0.30f
                title.textSize = fs
                val widths = word.map { title.measureText(it.toString()) }
                val sp = fs * 0.32f
                val total = widths.sum() + sp * (word.length - 1)
                val since = if (shockAt >= 0f) t - shockAt else 9f
                val breathe = 1f + 0.03f * sin(t * 2.4f) + smooth * 0.06f
                val baseY = cy - (title.descent() + title.ascent()) / 2f
                val sweep = ((t * 0.6f) % 1.6f) - 0.3f
                val s0 = sweep.coerceIn(0f, 1f)
                cv.save(); cv.scale(breathe, breathe, cx, cy)
                var px = cx - total / 2f
                word.forEachIndexed { i, ch ->
                    val a = ((since - 0.15f - i * 0.12f) / 0.35f).coerceIn(0f, 1f) * A
                    val rise = (1f - a) * fs * 0.25f
                    val mid = px + widths[i] / 2f
                    // cyan halo
                    title.shader = null
                    title.color = argb(0.55f * a, 150, 235, 255)
                    title.setShadowLayer(fs * 0.45f, 0f, 0f, argb(0.9f * a, 90, 220, 255))
                    cv.drawText(ch.toString(), mid, baseY + rise, title)
                    // white letter with a gold light sweeping across
                    title.setShadowLayer(fs * 0.18f, 0f, 0f, argb(0.8f * a, 255, 214, 74))
                    val wcol = argb(a, 255, 255, 255); val gold = argb(a, 255, 226, 120)
                    title.shader = android.graphics.LinearGradient(cx - total / 2f, 0f, cx + total / 2f, 0f,
                        intArrayOf(wcol, wcol, gold, wcol, wcol),
                        floatArrayOf(0f, (s0 - 0.12f).coerceIn(0f, 1f), s0, (s0 + 0.12f).coerceIn(0f, 1f), 1f), Shader.TileMode.CLAMP)
                    cv.drawText(ch.toString(), mid, baseY + rise, title)
                    px += widths[i] + sp
                }
                title.shader = null; title.clearShadowLayer()
                cv.restore()
            }

            // main ring glow
            val glow = 1f + smooth * 0.8f
            val u = R / 140f
            circleStroke(cv, cx, cy, R, 30f * u * glow, argb(0.06f * A, 120, 230, 160))
            circleStroke(cv, cx, cy, R, 18f * u * glow, argb(0.13f * A, 120, 230, 160))
            circleStroke(cv, cx, cy, R, 10f * u * glow, argb(0.32f * A, 255, 214, 74))
            circleStroke(cv, cx, cy, R, 5f * u * glow, argb(0.75f * A, 255, 214, 74))
            circleStroke(cv, cx, cy, R, 2.5f * u * glow, argb(A, 255, 230, 120))

            // comet sweeping around the ring
            val head = t * 2.4f
            for (k in 0 until 22) {
                val a0 = head - k * 0.035f
                arc(cv, cx, cy, R, a0 - 0.04f, 0.04f, (7f - k * 0.25f) * u * glow, argb((1f - k / 22f) * 0.9f * A, 255, 255, 230))
            }
            fill.color = argb(A, 255, 255, 255)
            cv.drawCircle(cx + cos(head) * R, cy + sin(head) * R, 4.5f * u * glow, fill)

            if (ans) { drawAnswer(cv, W, H, A); postInvalidateOnAnimation(); return }

            // voice wave
            val wy = H * 0.78f
            val st = W * 0.024f
            stroke.strokeWidth = st * 0.45f
            for (i in wave.indices) {
                val v = wave[wave.size - 1 - i]
                val h = (6f + v * 62f + 4f * sin(t * 9f + i)) * dens * A
                stroke.color = argb(0.9f * A * (1f - i / (wave.size + 4f)), 255, 205, 70)
                val dx = (i + 1.6f) * st
                cv.drawLine(cx - dx, wy - h / 2, cx - dx, wy + h / 2, stroke)
                cv.drawLine(cx + dx, wy - h / 2, cx + dx, wy + h / 2, stroke)
            }
            fill.color = argb(0.92f * A, 20, 24, 40); cv.drawCircle(cx, wy, st * 1.25f, fill)
            arc(cv, cx, wy, st * 1.25f, t * 3f, 4.6f, 2.5f * dens, argb(A, 255, 214, 74))
            fill.color = argb(A, 255, 255, 255); cv.drawCircle(cx, wy, st * 0.45f, fill)

            // what Ayaz is hearing (or "looking it up")
            if (thinking) {
                text.textSize = W * 0.04f; text.isFakeBoldText = false
                text.color = argb(0.75f * A, 200, 230, 255)
                cv.drawText("Bakıyorum…", cx, wy - W * 0.10f - W * 0.065f, text)
            }
            if (caption.isNotBlank()) {
                text.textSize = W * 0.045f; text.isFakeBoldText = false
                text.color = argb(A, 255, 255, 255)
                text.setShadowLayer(8f, 0f, 0f, Color.BLACK)
                cv.drawText(caption.take(42), cx, wy - W * 0.10f, text)
                text.clearShadowLayer()
            }
            postInvalidateOnAnimation()
        }

        private val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val bodyPaint = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG)

        private fun drawAnswer(cv: Canvas, W: Float, H: Float, A: Float) {
            val dens = resources.displayMetrics.density
            val pad = 20f * dens
            val left = 16f * dens; val right = W - 16f * dens
            val top = H * 0.38f
            val inner = (right - left - pad * 2).toInt()

            bodyPaint.color = argb(0.75f * A, 160, 215, 255)
            bodyPaint.textSize = 15f * dens
            val qLayout = android.text.StaticLayout.Builder.obtain(answerTitle, 0, answerTitle.length, bodyPaint, inner).setMaxLines(2)
                .setEllipsize(android.text.TextUtils.TruncateAt.END).build()
            val ansPaint = android.text.TextPaint(bodyPaint).apply {
                color = argb(A, 255, 255, 255)
                val long = (answerText?.length ?: 0) > 90 || (answerText?.lines()?.size ?: 0) > 3
                textSize = (if (long) 17f else 26f) * dens
                isFakeBoldText = !long
            }
            val a = answerText ?: ""
            val aLayout = android.text.StaticLayout.Builder.obtain(a, 0, a.length, ansPaint, inner).setMaxLines(14)
                .setEllipsize(android.text.TextUtils.TruncateAt.END).setLineSpacing(4f * dens, 1f).build()
            val bottom = (top + pad + qLayout.height + 12f * dens + aLayout.height + pad).coerceAtMost(H * 0.92f)

            // frosted panel with a gold edge, matching the ring
            panelPaint.shader = null; panelPaint.style = Paint.Style.FILL
            panelPaint.color = argb(0.55f * A, 10, 22, 55)
            cv.drawRoundRect(left, top, right, bottom, 22f * dens, 22f * dens, panelPaint)
            panelPaint.style = Paint.Style.STROKE; panelPaint.strokeWidth = 1.5f * dens
            panelPaint.color = argb(0.65f * A, 255, 214, 74)
            cv.drawRoundRect(left, top, right, bottom, 22f * dens, 22f * dens, panelPaint)

            cv.save(); cv.translate(left + pad, top + pad); qLayout.draw(cv)
            cv.translate(0f, qLayout.height + 12f * dens); aLayout.draw(cv); cv.restore()

            text.textSize = 12f * dens; text.isFakeBoldText = false; text.color = argb(0.55f * A, 200, 220, 255)
            cv.drawText("Kapatmak için dokun", W / 2f, (bottom + 22f * dens).coerceAtMost(H - 8f * dens), text)
        }
    }
}
