package com.resul.ayaz

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** "Durdur" in the notification: Ayaz stays off until you press "Başlat" */
class StopReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Prefs.setUserStopped(c, true)
        AyazService.stop(c)
        AyazTile.refresh(c)
        val nm = c.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel("ayaz_off") == null)
            nm.createNotificationChannel(NotificationChannel("ayaz_off", "Ayaz durduruldu", NotificationManager.IMPORTANCE_LOW))
        val start = PendingIntent.getActivity(c, 3, Intent(c, StartActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(5, Notification.Builder(c, "ayaz_off")
            .setSmallIcon(R.drawable.ic_ayaz)
            .setContentTitle("Ayaz durduruldu")
            .setContentText("Dinlemiyor. Tekrar açmak için Başlat'a dokun.")
            .setContentIntent(start)
            .setAutoCancel(true)
            .addAction(Notification.Action.Builder(null, "Başlat", start).build())
            .build())
    }
}
