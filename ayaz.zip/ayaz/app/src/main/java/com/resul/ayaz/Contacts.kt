package com.resul.ayaz

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract

data class Contact(val name: String, val number: String, val score: Double)

object Contacts {
    fun find(c: Context, spoken: String): Contact? {
        if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val q = trLower(spoken)
        var best: Contact? = null
        c.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )?.use { cur ->
            while (cur.moveToNext()) {
                val name = cur.getString(0) ?: continue
                val num = cur.getString(1) ?: continue
                val n = trLower(name)
                var s = nameScore(q, n)
                // "babama" -> "baba" also matches "Babam", "Babacım"
                if (s < 0.9 && n.split(" ").any { it.startsWith(q) || q.startsWith(it) && it.length >= 3 }) s = maxOf(s, 0.85)
                if (best == null || s > best!!.score) best = Contact(name, num, s)
            }
        }
        return best?.takeIf { it.score >= 0.55 }
    }

    /** WhatsApp wants 90XXXXXXXXXX */
    fun waNumber(raw: String): String {
        var n = raw.filter { it.isDigit() }
        if (n.startsWith("00")) n = n.drop(2)
        if (n.startsWith("0")) n = "90" + n.drop(1)
        if (n.length == 10 && n.startsWith("5")) n = "90$n"
        return n
    }
}
