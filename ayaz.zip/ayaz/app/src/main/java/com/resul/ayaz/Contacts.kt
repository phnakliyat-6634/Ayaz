package com.resul.ayaz

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract

data class Contact(val name: String, val number: String, val score: Double)

object Contacts {
    private var cache: List<Pair<String, String>> = emptyList()
    private var cachedAt = 0L

    private fun all(c: Context): List<Pair<String, String>> {
        if (System.currentTimeMillis() - cachedAt < 5 * 60_000 && cache.isNotEmpty()) return cache
        val out = ArrayList<Pair<String, String>>()
        c.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )?.use { cur ->
            while (cur.moveToNext()) {
                val name = cur.getString(0) ?: continue
                val num = cur.getString(1) ?: continue
                out += name to num
            }
        }
        cache = out.distinctBy { it.first }
        cachedAt = System.currentTimeMillis()
        return cache
    }

    private fun words(s: String) = trLower(s).replace(Regex("[^\\p{L}\\p{N} ]"), " ").split(" ").filter { it.isNotBlank() }

    /** one spoken word vs one name word; tolerates suffixes ("kardeş" ~ "kardeşim") */
    private fun wordScore(q: String, n: String): Double {
        if (q == n) return 1.0
        if (q.length >= 3 && (n.startsWith(q) || q.startsWith(n) && n.length >= 3)) return 0.92
        return similarity(q, n)
    }

    /** every spoken word must match some word of the name: "şeyma kızım" never picks "Gizem kızım" */
    private fun score(query: List<String>, name: List<String>): Double {
        if (query.isEmpty() || name.isEmpty()) return 0.0
        var sum = 0.0
        var worst = 1.0
        for (q in query) {
            val best = name.maxOf { wordScore(q, it) }
            sum += best; worst = minOf(worst, best)
        }
        var s = sum / query.size
        if (worst < 0.6) s = minOf(s, worst + 0.1)        // one word clearly wrong -> low
        if (name.size > query.size) s -= 0.03 * (name.size - query.size)
        return s
    }

    fun find(c: Context, spoken: String): Contact? {
        if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val q = words(spoken)
        if (q.isEmpty()) return null
        val ranked = all(c).map { (name, num) -> Contact(name, num, score(q, words(name))) }
            .sortedByDescending { it.score }
        val best = ranked.firstOrNull() ?: return null
        if (best.score < 0.6) return null
        val second = ranked.getOrNull(1)
        // two different people almost equally likely ("kardeş": Mehmet kardeşim / Ali kardeşim) -> ask
        return if (second != null && best.score - second.score < 0.04 && best.score < 0.99) best.copy(score = minOf(best.score, 0.79))
        else best
    }

    /** WhatsApp wants 90XXXXXXXXXX */
    fun waNumber(raw: String): String {
        var n = raw.filter { it.isDigit() }
        if (n.startsWith("00")) n = n.drop(2)
        if (n.startsWith("0")) n = "90" + n.drop(1)
        if (n.length == 10 && n.startsWith("5")) n = "90$n"
        return n
    }
}
