package com.resul.ayaz

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("ayaz", Context.MODE_PRIVATE)

    fun voice(c: Context): FloatArray? =
        p(c).getString("voice", null)?.split(",")?.mapNotNull { it.toFloatOrNull() }
            ?.takeIf { it.isNotEmpty() }?.toFloatArray()

    fun setVoice(c: Context, v: FloatArray?) {
        p(c).edit().putString("voice", v?.joinToString(",")).apply()
    }

    fun threshold(c: Context): Float = p(c).getFloat("threshold", 0.55f)
    fun setThreshold(c: Context, v: Float) = p(c).edit().putFloat("threshold", v).apply()

    fun lastDistance(c: Context): Float = p(c).getFloat("lastDistance", -1f)
    fun setLastDistance(c: Context, v: Float) = p(c).edit().putFloat("lastDistance", v).apply()

    fun sleeping(c: Context): Boolean = p(c).getBoolean("sleeping", false)
    fun setSleeping(c: Context, v: Boolean) = p(c).edit().putBoolean("sleeping", v).apply()

    fun gestures(c: Context): Boolean = p(c).getBoolean("gestures", false)
    fun setGestures(c: Context, v: Boolean) = p(c).edit().putBoolean("gestures", v).apply()

    fun invertGesture(c: Context): Boolean = p(c).getBoolean("invertGesture", false)
    fun setInvertGesture(c: Context, v: Boolean) = p(c).edit().putBoolean("invertGesture", v).apply()

    fun overlay(c: Context): Boolean = p(c).getBoolean("overlay", true)
    fun setOverlay(c: Context, v: Boolean) = p(c).edit().putBoolean("overlay", v).apply()

    fun repo(c: Context): String = p(c).getString("repo", "") ?: ""
    fun setRepo(c: Context, v: String) = p(c).edit().putString("repo", v.trim()).apply()

    fun log(c: Context, line: String) {
        val time = SimpleDateFormat("HH:mm", Locale("tr", "TR")).format(Date())
        val cur = (p(c).getString("log", "") ?: "").lines().filter { it.isNotBlank() }.takeLast(39)
        p(c).edit().putString("log", (cur + "$time  $line").joinToString("\n")).apply()
    }

    fun logText(c: Context): String = p(c).getString("log", "") ?: ""
}
