package com.resul.ayaz

import java.util.Locale

val TR: Locale = Locale("tr", "TR")

fun trLower(s: String): String =
    s.lowercase(TR).replace("ınstagram", "instagram")
        .replace('’', '\'').replace(Regex("\\s+"), " ").trim()

fun capFirst(s: String): String = s.replaceFirstChar { it.titlecase(TR) }

/** Levenshtein-based similarity, 0..1 */
fun similarity(a: String, b: String): Double {
    if (a == b) return 1.0
    if (a.isEmpty() || b.isEmpty()) return 0.0
    val dp = IntArray(b.length + 1) { it }
    for (i in 1..a.length) {
        var prev = dp[0]; dp[0] = i
        for (j in 1..b.length) {
            val tmp = dp[j]
            dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
            prev = tmp
        }
    }
    return 1.0 - dp[b.length].toDouble() / maxOf(a.length, b.length)
}

fun nameScore(query: String, name: String): Double {
    val q = query.replace(Regex("[^\\p{L}\\p{N}]"), "")
    val n = name.replace(Regex("[^\\p{L}\\p{N}]"), "")
    if (q.isEmpty() || n.isEmpty()) return 0.0
    if (q == n) return 1.0
    if (n.startsWith(q) || q.startsWith(n)) return 0.9
    if (n.contains(q) || q.contains(n)) return 0.8
    return similarity(q, n)
}

private val YES = Regex("(?<!\\p{L})(evet|olur|tamam|aynen|doğru|he|hı hı|onayla|gönder)(?!\\p{L})")
private val NO = Regex("(?<!\\p{L})(hayır|yok|iptal|vazgeç|istemiyorum|olmaz|yanlış)(?!\\p{L})")

/** true / false / null (unclear) */
fun parseYes(text: String): Boolean? {
    val t = trLower(text)
    return when {
        NO.containsMatchIn(t) -> false
        YES.containsMatchIn(t) -> true
        else -> null
    }
}
