package com.resul.ayaz

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date

/** A short, sure answer to a question, checked with Google Search through the Gemini API (user's own free key). */
data class Answer(val sure: Boolean, val spoken: String, val display: String)

object Answers {
    private val MODELS = listOf("gemini-3.8-flash", "gemini-3.5-flash", "gemini-3.1-flash-lite")

    private fun post(url: String, key: String, body: JSONObject): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.connectTimeout = 15000; c.readTimeout = 45000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        return code to text
    }

    /** every text block of the model's answer, wherever the API puts it */
    private fun collectText(o: Any?, out: StringBuilder) {
        when (o) {
            is JSONObject -> {
                if (o.optString("type") == "text" && o.has("text")) out.append(o.optString("text")).append('\n')
                // older generateContent shape: candidates[].content.parts[].text
                if (o.has("parts")) collectText(o.optJSONArray("parts"), out)
                else for (k in o.keys()) if (k != "text" && k != "annotations" && k != "search_suggestions") collectText(o.opt(k), out)
            }
            is JSONArray -> for (i in 0 until o.length()) collectText(o.opt(i), out)
        }
        if (o is JSONObject && o.has("parts")) return
    }

    private fun partsText(o: JSONObject): String {
        // interactions API: steps[].type == "model_output" -> content[].text
        val steps = o.optJSONArray("steps")
        val sb = StringBuilder()
        if (steps != null) {
            for (i in 0 until steps.length()) {
                val st = steps.optJSONObject(i) ?: continue
                if (st.optString("type") == "model_output") collectText(st.opt("content"), sb)
            }
        }
        if (sb.isBlank()) {
            o.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")?.let { p ->
                for (i in 0 until p.length()) sb.append(p.optJSONObject(i)?.optString("text") ?: "")
            }
        }
        if (sb.isBlank()) collectText(o.opt("outputs") ?: o, sb)
        return sb.toString().trim()
    }

    fun ask(c: Context, question: String, place: String?): Answer? {
        val key = Prefs.geminiKey(c)
        if (key.isBlank()) return null
        val today = SimpleDateFormat("d MMMM yyyy EEEE, HH:mm", TR).format(Date())
        val prompt = """
            Sen Ayaz adlı Türkçe sesli asistansın. Soruyu mutlaka Google aramasıyla kontrol ederek yanıtla.
            Bugün: $today (Türkiye saati). Kullanıcının konumu: ${place ?: "bilinmiyor"}.
            Yalnızca şu JSON'u döndür, başka hiçbir şey yazma:
            {"kesin": true, "soz": "sesli okunacak en fazla 2 kısa cümle", "ekran": "ekranda gösterilecek kısa ve net cevap; liste gerekiyorsa en fazla 10 satır, her satır ayrı"}
            Cevap net tek bir bilgiyse (saat, tarih, skor, puan durumu, sayı, uzunluk, mesafe, kişi, yer) kesin=true yap.
            Soru görüş, öneri, uzun araştırma ya da çok kaynak gerektiriyorsa ya da emin değilsen kesin=false yap ve diğer alanları boş bırak.
            Maç saati gibi zaman bilgilerini Türkiye saatiyle ver. Sayıları rakamla yaz.
            Soru: $question
        """.trimIndent()
        for (m in MODELS) {
            val body = JSONObject().put("model", m).put("input", prompt)
                .put("tools", JSONArray().put(JSONObject().put("type", "google_search")))
            var (code, text) = try { post("https://generativelanguage.googleapis.com/v1beta/interactions", key, body) } catch (e: Exception) { -1 to (e.message ?: "") }
            if (code == 404) {
                // older endpoint, in case the account does not have the new one
                val legacy = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                    .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
                val r = try { post("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent", key, legacy) } catch (e: Exception) { -1 to (e.message ?: "") }
                code = r.first; text = r.second
            }
            if (code in 200..299) return parse(partsText(JSONObject(text)))
            Prefs.log(c, "Gemini ($m) hata $code: ${text.take(160)}")
            if (code == 400 || code == 401 || code == 403 || code == 429) {
                if (code != 400 || !text.contains("model", true)) break    // key or quota problem: other models won't help
            }
        }
        return null
    }

    private fun parse(raw: String): Answer? {
        if (raw.isBlank()) return null
        val i = raw.indexOf('{'); val j = raw.lastIndexOf('}')
        if (i >= 0 && j > i) {
            try {
                val o = JSONObject(raw.substring(i, j + 1))
                val sure = o.optBoolean("kesin", false)
                val soz = o.optString("soz").trim(); val ekran = o.optString("ekran").trim()
                if (!sure || (soz.isEmpty() && ekran.isEmpty())) return Answer(false, "", "")
                return Answer(true, soz.ifEmpty { ekran.lines().first() }, ekran.ifEmpty { soz })
            } catch (_: Exception) {}
        }
        val clean = raw.replace(Regex("[*#`]"), "").trim()
        return Answer(true, clean.lines().first().take(200), clean.take(600))
    }
}

/** Road distance and drive time: Open-Meteo place search + the public OSRM router. */
object Route {
    private fun get(url: String): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "Ayaz")
        return JSONObject(c.inputStream.bufferedReader().readText())
    }

    /** km and minutes by car */
    fun drive(fromLat: Double, fromLon: Double, toLat: Double, toLon: Double): Pair<Double, Int>? {
        val o = get("https://router.project-osrm.org/route/v1/driving/$fromLon,$fromLat;$toLon,$toLat?overview=false")
        val r = o.optJSONArray("routes")?.optJSONObject(0) ?: return null
        return (r.getDouble("distance") / 1000.0) to (r.getDouble("duration") / 60.0).toInt()
    }

    fun duration(min: Int): String {
        val h = min / 60; val m = min % 60
        return listOfNotNull(if (h > 0) "$h saat" else null, if (m > 0 || h == 0) "$m dakika" else null).joinToString(" ")
    }
}
