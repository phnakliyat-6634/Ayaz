package com.resul.ayaz

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import kotlin.math.abs

/**
 * Front-camera hand-swipe detector. Runs entirely on the phone: it compares
 * tiny grayscale frames and follows where the movement goes. No image is stored.
 */
class MotionDetector(private val c: Context, private val onGesture: (Gesture) -> Unit) {
    enum class Gesture { UP, SIDE }

    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var reader: ImageReader? = null
    private val main = Handler(Looper.getMainLooper())

    private val W = 48
    private val H = 36
    private var prev: IntArray? = null
    private val track = ArrayList<Triple<Long, Float, Float>>()
    private var cooldownUntil = 0L
    private var sensorOrientation = 270
    @Volatile var running = false
        private set

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        if (running) return true
        if (c.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return false
        val cm = c.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
        } ?: return false
        sensorOrientation = cm.getCameraCharacteristics(id).get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 270
        val t = HandlerThread("ayaz-cam").also { it.start() }
        thread = t
        val h = Handler(t.looper)
        handler = h
        val r = ImageReader.newInstance(320, 240, ImageFormat.YUV_420_888, 2)
        reader = r
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = img.planes[0]
                val buf = plane.buffer
                val rs = plane.rowStride
                val ps = plane.pixelStride
                val g = IntArray(W * H)
                for (y in 0 until H) for (x in 0 until W) {
                    val sx = x * img.width / W
                    val sy = y * img.height / H
                    g[y * W + x] = buf.get(sy * rs + sx * ps).toInt() and 0xFF
                }
                analyze(g)
            } catch (_: Exception) {
            } finally { img.close() }
        }, h)
        running = true
        try {
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(cd: CameraDevice) {
                    device = cd
                    @Suppress("DEPRECATION")
                    cd.createCaptureSession(listOf(r.surface), object : CameraCaptureSession.StateCallback() {
                        override fun onConfigured(s: CameraCaptureSession) {
                            session = s
                            val req = cd.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply { addTarget(r.surface) }
                            try { s.setRepeatingRequest(req.build(), null, h) } catch (_: Exception) {}
                        }
                        override fun onConfigureFailed(s: CameraCaptureSession) { stop() }
                    }, h)
                }
                override fun onDisconnected(cd: CameraDevice) { stop() }
                override fun onError(cd: CameraDevice, error: Int) { stop() }
            }, h)
        } catch (e: Exception) { stop(); return false }
        return true
    }

    fun stop() {
        running = false
        try { session?.close() } catch (_: Exception) {}
        try { device?.close() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        session = null; device = null; reader = null
        thread?.quitSafely(); thread = null; handler = null
        prev = null; track.clear()
    }

    /** image coords -> upright portrait coords (0..1) */
    private fun upright(xn: Float, yn: Float): Pair<Float, Float> = when (sensorOrientation) {
        90 -> (1f - yn) to xn
        180 -> (1f - xn) to (1f - yn)
        270 -> yn to (1f - xn)
        else -> xn to yn
    }

    private fun analyze(g: IntArray) {
        val p = prev
        prev = g
        if (p == null) return
        val now = System.currentTimeMillis()
        if (now < cooldownUntil) return
        var n = 0; var sx = 0f; var sy = 0f
        for (i in g.indices) {
            if (abs(g[i] - p[i]) > 28) { n++; sx += (i % W); sy += (i / W) }
        }
        val frac = n.toFloat() / g.size
        if (frac in 0.03f..0.6f) {
            val (ux, uy) = upright(sx / n / W, sy / n / H)
            track += Triple(now, ux, uy)
        }
        track.removeAll { now - it.first > 700 }
        if (track.size < 4) return
        val first = track.first(); val last = track.last()
        val dx = last.second - first.second
        var dy = first.third - last.third          // positive = hand moved up
        if (Prefs.invertGesture(c)) dy = -dy
        val gesture = when {
            dy > 0.35f && abs(dy) > 1.5f * abs(dx) -> Gesture.UP
            abs(dx) > 0.35f && abs(dx) > 1.5f * abs(dy) -> Gesture.SIDE
            else -> null
        } ?: return
        cooldownUntil = now + 1500
        track.clear()
        main.post { onGesture(gesture) }
    }
}
