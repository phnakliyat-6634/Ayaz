package com.resul.ayaz

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Only acts on the user's spoken "gönder" / "düzelt" commands inside WhatsApp. */
class AyazAccessibility : AccessibilityService() {
    companion object { var instance: AyazAccessibility? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private val waPkgs = listOf("com.whatsapp", "com.whatsapp.w4b")

    private fun findById(name: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        for (p in waPkgs) {
            root.findAccessibilityNodeInfosByViewId("$p:id/$name")?.firstOrNull()?.let { return it }
        }
        return null
    }

    fun clickWhatsAppSend(): Boolean {
        var node = findById("send")
        if (node == null) {
            val root = rootInActiveWindow ?: return false
            node = (root.findAccessibilityNodeInfosByText("Gönder") + root.findAccessibilityNodeInfosByText("Send"))
                .firstOrNull { it.isClickable || it.parent?.isClickable == true }
        }
        var n = node ?: return false
        while (!n.isClickable && n.parent != null) n = n.parent
        return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    fun setWhatsAppText(text: String): Boolean {
        val entry = findById("entry") ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return entry.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }
}
