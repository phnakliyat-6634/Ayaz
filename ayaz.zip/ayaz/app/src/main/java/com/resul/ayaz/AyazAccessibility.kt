package com.resul.ayaz

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Only acts on the user's spoken "gönder" / "düzelt" commands inside WhatsApp. */
class AyazAccessibility : AccessibilityService() {
    companion object { var instance: AyazAccessibility? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        AyazService.instance?.onForegroundApp(pkg)
    }

    /** swipe like a finger: up = next video, down = previous */
    fun swipe(up: Boolean): Boolean {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val y1 = dm.heightPixels * (if (up) 0.75f else 0.30f)
        val y2 = dm.heightPixels * (if (up) 0.25f else 0.80f)
        val path = android.graphics.Path().apply { moveTo(x, y1); lineTo(x, y2) }
        val stroke = android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 250)
        return dispatchGesture(android.accessibilityservice.GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }
    override fun onInterrupt() {}

    private val waPkgs = listOf("com.whatsapp", "com.whatsapp.w4b")

    private fun findById(name: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        for (p in waPkgs) {
            root.findAccessibilityNodeInfosByViewId("$p:id/$name")?.firstOrNull()?.let { return it }
        }
        return null
    }

    fun clickWhatsAppSend(): Boolean {
        var node = findById("send")
        if (node == null) {
            val root = rootInActiveWindow ?: return false
            node = (root.findAccessibilityNodeInfosByText("Gönder") + root.findAccessibilityNodeInfosByText("Send"))
                .firstOrNull { it.isClickable || it.parent?.isClickable == true }
        }
        var n = node ?: return false
        while (!n.isClickable && n.parent != null) n = n.parent
        return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    fun global(action: Int): Boolean = performGlobalAction(action)

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        while (n != null && !n.isClickable) n = n.parent
        return n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }

    private fun walk(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null) return
        out += n
        for (i in 0 until n.childCount) walk(n.getChild(i), out)
    }

    /** a finger tap at a screen point */
    fun tapAt(x: Float, y: Float): Boolean {
        val path = android.graphics.Path().apply { moveTo(x, y) }
        val stroke = android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 60)
        return dispatchGesture(android.accessibilityservice.GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun bounds(n: AccessibilityNodeInfo) = android.graphics.Rect().also { n.getBoundsInScreen(it) }

    /**
     * Finds the newest location in the open WhatsApp chat and taps it.
     * A location is shown as a map picture, so besides text ("Konum") it also
     * looks at view ids and, as a last resort, the lowest large picture bubble.
     */
    fun clickLastLocation(): Boolean {
        val root = rootInActiveWindow ?: return false
        val all = mutableListOf<AccessibilityNodeInfo>()
        walk(root, all)
        val dm = resources.displayMetrics
        val top = dm.heightPixels * 0.10f
        val bottom = dm.heightPixels * 0.88f          // above the message box
        fun visible(n: AccessibilityNodeInfo): Boolean {
            val r = bounds(n); return r.height() > 20 && r.centerY() > top && r.centerY() < bottom
        }
        fun label(n: AccessibilityNodeInfo) = ((n.contentDescription?.toString() ?: "") + " " + (n.text?.toString() ?: "")).lowercase(TR)
        fun id(n: AccessibilityNodeInfo) = (n.viewIdResourceName ?: "").lowercase()

        // 1) text or description says it is a location / map
        val words = listOf("konum", "location", "harita", "google.com/maps", "maps.app.goo.gl", "goo.gl/maps")
        var hits = all.filter { visible(it) && words.any { w -> label(it).contains(w) } && !id(it).contains("entry") }
        // 2) WhatsApp view ids for location bubbles
        if (hits.isEmpty()) hits = all.filter { visible(it) && (id(it).contains("location") || id(it).contains("map") ) }
        // 3) the lowest wide picture in the chat (the map preview)
        if (hits.isEmpty()) hits = all.filter { n ->
            val r = bounds(n)
            visible(n) && (n.className?.toString()?.contains("Image") == true || id(n).contains("thumb") || id(n).contains("image")) &&
                r.width() > dm.widthPixels * 0.45f && r.height() > dm.heightPixels * 0.12f
        }
        val best = hits.maxByOrNull { bounds(it).bottom }
        if (best == null) {
            // leave a trace so the next fix can be exact
            val sample = all.filter { visible(it) }.takeLast(12).joinToString(" ; ") {
                "${it.className?.toString()?.substringAfterLast('.')}#${id(it).substringAfter("id/")}:${label(it).take(20)}"
            }
            AyazService.instance?.log("Konum bulunamadı. Ekran: $sample")
            return false
        }
        val r = bounds(best)
        return tapAt(r.exactCenterX(), r.exactCenterY())
    }

    // ---------- general screen actions: find and tap anything, type into search ----------
    private val ui = android.os.Handler(android.os.Looper.getMainLooper())

    private fun matchScore(n: AccessibilityNodeInfo, targets: List<String>): Double {
        val raw = listOfNotNull(n.text?.toString(), n.contentDescription?.toString()).joinToString(" ").trim()
        if (raw.isEmpty() || raw.length > 80) return 0.0
        val s = raw.lowercase(TR)
        var best = 0.0
        for (t0 in targets) {
            val t = t0.lowercase(TR).trim()
            if (t.isEmpty()) continue
            val sc = when {
                s == t -> 1.0
                s.startsWith(t) || s.split(" ").any { it == t } -> 0.93
                s.contains(t) -> 0.85
                else -> maxOf(similarity(s, t), s.split(" ").maxOf { similarity(it, t) } * 0.95)
            }
            if (sc > best) best = sc
        }
        return best
    }

    /** best visible element for the words; null if nothing is close enough */
    fun findNode(targets: List<String>): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val all = mutableListOf<AccessibilityNodeInfo>()
        walk(root, all)
        return all.filter { it.isVisibleToUser }
            .map { it to matchScore(it, targets) }
            .filter { it.second >= 0.8 }
            .maxByOrNull { it.second }?.first
    }

    private fun tapNode(n: AccessibilityNodeInfo): Boolean {
        if (clickNode(n)) return true
        val r = bounds(n)
        return r.width() > 0 && tapAt(r.exactCenterX(), r.exactCenterY())
    }

    private fun scrollForward(): Boolean {
        val root = rootInActiveWindow ?: return false
        val all = mutableListOf<AccessibilityNodeInfo>()
        walk(root, all)
        val list = all.filter { it.isScrollable && it.isVisibleToUser }.maxByOrNull { bounds(it).height() } ?: return false
        return list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    /** finds the words on screen (scrolling if allowed) and taps them; answers on the main thread */
    fun findAndTap(targets: List<String>, scroll: Boolean, tries: Int = 0, done: (Boolean) -> Unit) {
        val n = findNode(targets)
        if (n != null) { done(tapNode(n)); return }
        if (!scroll || tries >= 8 || !scrollForward()) { done(false); return }
        ui.postDelayed({ findAndTap(targets, scroll, tries + 1, done) }, 650)
    }

    /** types into the app's search box (opening it first if needed) and presses enter */
    fun typeSearch(q: String, tries: Int = 0, done: (Boolean) -> Unit) {
        val root = rootInActiveWindow ?: run { done(false); return }
        val all = mutableListOf<AccessibilityNodeInfo>()
        walk(root, all)
        val field = all.firstOrNull { it.isEditable && it.isFocused } ?: all.firstOrNull { it.isEditable && it.isVisibleToUser }
        if (field != null) {
            field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, q) }
            val ok = field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            if (ok && android.os.Build.VERSION.SDK_INT >= 30)
                ui.postDelayed({ field.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id) }, 300)
            done(ok); return
        }
        if (tries >= 2) { done(false); return }
        val btn = findNode(listOf("Ara", "Arama", "Search", "Ara…", "Search…"))
        if (btn == null) { done(false); return }
        tapNode(btn)
        ui.postDelayed({ typeSearch(q, tries + 1, done) }, 900)
    }

    /** after tapping a location: if WhatsApp shows its own map or an "open with" list, continue to Google Maps */
    fun continueToMaps(): Boolean =
        clickText(listOf("Google Haritalar", "Haritalar", "Google Maps", "Maps", "Haritada aç", "Yol tarifi", "Directions"))

    /** all visible text in the app on screen, plus its package name */
    fun screenText(): Pair<String, String>? {
        val root = rootInActiveWindow ?: return null
        val all = mutableListOf<AccessibilityNodeInfo>()
        walk(root, all)
        val sb = StringBuilder()
        for (n in all) {
            n.text?.let { sb.append(it).append(" | ") }
            n.contentDescription?.let { sb.append(it).append(" | ") }
        }
        return (root.packageName?.toString() ?: "") to sb.toString()
    }

    /** taps the first visible button whose text or description matches one of the words */
    fun clickText(words: List<String>): Boolean {
        val root = rootInActiveWindow ?: return false
        for (w in words) {
            val nodes = root.findAccessibilityNodeInfosByText(w) ?: continue
            for (n in nodes) if (clickNode(n)) return true
        }
        return false
    }

    fun setWhatsAppText(text: String): Boolean {
        val entry = findById("entry") ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return entry.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }
}
