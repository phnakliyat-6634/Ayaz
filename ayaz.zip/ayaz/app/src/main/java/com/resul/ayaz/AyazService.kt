package com.resul.ayaz

import android.Manifest
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.SpeakerModel
import org.vosk.android.SpeechService
import android.speech.RecognitionListener as AndroidListener
import org.vosk.android.RecognitionListener as VoskListener

class AyazService : Service(), VoskListener {

    companion object {
        @Volatile var running = false
        var instance: AyazService? = null
        private const val CH = "ayaz"

        fun start(c: Context) {
            val i = Intent(c, AyazService::class.java)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }
        fun stop(c: Context) { c.stopService(Intent(c, AyazService::class.java)) }
    }

    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var spk: SpeakerModel? = null
    private var rec: Recognizer? = null
    private var speech: SpeechService? = null
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val ttsDone = HashMap<String, () -> Unit>()
    private var uttId = 0
    @Volatile private var busy = false
    lateinit var engine: CommandEngine

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        instance = this
        startInForeground()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ||
            !ModelManager.ready(this)) {
            Prefs.log(this, "Başlatılamadı: mikrofon izni veya ses modeli eksik")
            stopSelf(); return
        }
        engine = CommandEngine(this)
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.language = TR
                ttsReady = true
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { fire(id) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { fire(id) }
            private fun fire(id: String?) {
                val cb = synchronized(ttsDone) { ttsDone.remove(id) } ?: return
                main.post(cb)
            }
        })
        Thread {
            try {
                val (m, s) = ModelManager.load(this)
                model = m; spk = s
                main.post { startWake(); Prefs.log(this, "Ayaz dinlemeye başladı") }
            } catch (e: Exception) {
                Prefs.log(this, "Model yüklenemedi: ${e.message}")
                main.post { stopSelf() }
            }
        }.start()
        AyazTile.refresh(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        instance = null
        stopWake()
        stopGestures()
        sr?.destroy(); sr = null
        tts?.shutdown()
        AyazTile.refresh(this)
        super.onDestroy()
    }

    // ---------- notification ----------
    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            nm.createNotificationChannel(NotificationChannel(CH, "Ayaz", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE)
        val text = if (Prefs.sleeping(this)) "Uykuda · uyandırmak için \"Ayaz aç\" de" else "Dinliyor · \"Ayaz\" de, bipten sonra komutunu söyle"
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_ayaz)
            .setContentTitle("Ayaz")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    private fun startInForeground() {
        val n = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                startForeground(1, n, type)
            } else if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
        } catch (e: Exception) {
            Prefs.log(this, "Arka planda başlatılamadı, kutucuktan tekrar aç")
            stopSelf()
        }
    }

    // ---------- hand gestures in video apps ----------
    private val VIDEO_APPS = setOf("com.google.android.youtube", "com.instagram.android", "com.facebook.katana",
        "com.facebook.lite", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill")
    private val IGNORE = setOf("com.android.systemui", "com.resul.ayaz", "com.miui.home.launcher.assistant")
    private var detector: MotionDetector? = null

    fun onForegroundApp(pkg: String) {
        if (pkg in IGNORE || pkg.contains("inputmethod") || pkg.contains("keyboard")) return
        if (Prefs.gestures(this) && pkg in VIDEO_APPS) startGestures() else stopGestures()
    }

    private fun startGestures() {
        if (detector?.running == true) return
        val d = MotionDetector(this) { g -> onGesture(g) }
        if (d.start()) detector = d else Prefs.log(this, "El hareketi için kamera açılamadı")
    }

    private fun onGesture(g: MotionDetector.Gesture) {
        val acc = AyazAccessibility.instance
        if (acc == null) { Prefs.log(this, "El hareketi algılandı ama Erişilebilirlik izni kapalı"); return }
        if (g == MotionDetector.Gesture.UP) { acc.swipe(true); Prefs.log(this, "El hareketi: yukarı → sonraki video") }
        else { acc.swipe(false); Prefs.log(this, "El hareketi: yana → önceki video") }
    }

    fun stopGestures() { detector?.stop(); detector = null }

    fun updateNotification() {
        getSystemService(NotificationManager::class.java).notify(1, buildNotification())
    }

    // ---------- wake word (Vosk, offline) ----------
    private fun startWake() {
        if (speech != null || busy) return
        val m = model ?: return
        try {
            val r = Recognizer(m, 16000f)   // full sentence, so "Ayaz Google'ı aç" works in one breath
            spk?.let { r.setSpeakerModel(it) }
            rec = r
            speech = SpeechService(r, 16000f).also { it.startListening(this) }
        } catch (e: Exception) {
            Prefs.log(this, "Mikrofon açılamadı: ${e.message}")
            main.postDelayed({ startWake() }, 5000)
        }
    }

    private fun stopWake() {
        try { speech?.stop(); speech?.shutdown() } catch (_: Exception) {}
        speech = null
        try { rec?.close() } catch (_: Exception) {}
        rec = null
    }

    private fun resumeWake() {
        main.postDelayed({ if (!busy && sr == null) startWake() }, 700)
    }

    override fun onPartialResult(hypothesis: String?) {}
    override fun onResult(hypothesis: String?) { handleWake(hypothesis) }
    override fun onFinalResult(hypothesis: String?) { handleWake(hypothesis) }
    override fun onError(exception: Exception?) {
        Prefs.log(this, "Dinleme hatası: ${exception?.message}")
        stopWake(); resumeWake()
    }
    override fun onTimeout() { stopWake(); resumeWake() }

    @Volatile private var speakingUntil = 0L

    private fun handleWake(h: String?) {
        if (h == null || busy) return
        // never react to Ayaz's own voice ("…Ayaz, gönder de")
        if (tts?.isSpeaking == true || System.currentTimeMillis() < speakingUntil) return
        val o = try { JSONObject(h) } catch (e: Exception) { return }
        val text = o.optString("text").trim()
        val rest = afterWake(text) ?: return
        if (!Voice.verify(this, Voice.vec(o))) {
            Prefs.log(this, "Tanınmayan ses reddedildi (mesafe %.2f)".format(Prefs.lastDistance(this)))
            return
        }
        Prefs.log(this, "Duydum: $text")
        when {
            Regex("^(kapat|kapan|uyu)$").matches(rest) -> {
                if (!Prefs.sleeping(this)) {
                    Prefs.setSleeping(this, true); updateNotification(); AyazTile.refresh(this)
                    say("Uyku moduna geçiyorum. Uyandırmak için Ayaz aç de.")
                }
            }
            Regex("^(aç|uyan|açıl)$").matches(rest) -> {
                val wasSleeping = Prefs.sleeping(this)
                Prefs.setSleeping(this, false); updateNotification(); AyazTile.refresh(this)
                if (screenLocked()) showWakeScreen()
                say(if (wasSleeping) "Buradayım" else "Zaten açığım")
            }
            Prefs.sleeping(this) -> {}
            rest.isEmpty() -> {
                // only "Ayaz": beep and listen with Google, as before
                if (screenLocked()) showWakeScreen()
                listenCommand(null) { t, conf -> engine.handle(t, conf) }
            }
            else -> {
                // "Ayaz Google'ı aç" in one breath: run it right away
                if (screenLocked()) showWakeScreen()
                try { engine.handle(rest, -1f, quick = true) }
                catch (e: Exception) { Prefs.log(this, "Komut hatası: ${e.message}") }
            }
        }
    }

    private fun screenLocked(): Boolean {
        val km = getSystemService(KeyguardManager::class.java)
        val pm = getSystemService(PowerManager::class.java)
        return km.isKeyguardLocked || !pm.isInteractive
    }

    private fun showWakeScreen() {
        try {
            startActivity(Intent(this, WakeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
    }

    // ---------- command listening (Google speech, accurate Turkish) ----------
    fun listenCommand(prompt: String?, cb: (String, Float) -> Unit) {
        busy = true
        stopWake()
        if (prompt != null) say(prompt) { main.postDelayed({ startSR(cb) }, 150) }
        else { beep(); main.postDelayed({ startSR(cb) }, 350) }
    }

    fun ask(prompt: String, cb: (Boolean?) -> Unit) {
        listenCommand(prompt) { t, _ -> cb(parseYes(t)) }
    }

    private fun startSR(cb: (String, Float) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            busy = false
            say("Telefonda Google ses tanıma bulunamadı."); resumeWake(); return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : AndroidListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val conf = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
                endSR()
                busy = false
                if (list.isNullOrEmpty()) { say("Duyamadım"); resumeWake(); return }
                try { cb(list[0], conf?.firstOrNull() ?: -1f) }
                catch (e: Exception) { Prefs.log(this@AyazService, "Komut hatası: ${e.message}"); say("Bunu yaparken bir hata oldu") }
                if (!busy) resumeWake()
            }
            override fun onError(error: Int) {
                endSR()
                busy = false
                if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) say("Duyamadım")
                else Prefs.log(this@AyazService, "Ses tanıma hatası: $error")
                resumeWake()
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        r.startListening(i)
    }

    private fun endSR() { try { sr?.destroy() } catch (_: Exception) {}; sr = null }

    // ---------- voice output ----------
    fun say(text: String, onDone: (() -> Unit)? = null) {
        Prefs.log(this, "Ayaz: $text")
        val t = tts
        if (!ttsReady || t == null) { onDone?.let { main.post(it) }; return }
        val id = "u${uttId++}"
        speakingUntil = System.currentTimeMillis() + 1500 + text.length * 90L
        val userDone = onDone
        synchronized(ttsDone) {
            ttsDone[id] = {
                speakingUntil = System.currentTimeMillis() + 700
                userDone?.invoke()
            }
        }
        t.speak(text, TextToSpeech.QUEUE_ADD, null, id)
    }

    fun sayQueue(lines: List<String>) { lines.forEach { say(it) } }

    private fun beep() {
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 70).startTone(ToneGenerator.TONE_PROP_BEEP, 150) } catch (_: Exception) {}
    }

    fun log(s: String) = Prefs.log(this, s)
}
