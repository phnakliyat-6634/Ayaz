package com.resul.ayaz

import android.content.Context
import org.json.JSONObject

/** User's own short info: "web sitem", "benim ibanım", "babamın ibanı"... Stored only on this phone. */
object Shortcuts {
    private fun p(c: Context) = c.getSharedPreferences("ayaz_shortcuts", Context.MODE_PRIVATE)

    fun all(c: Context): LinkedHashMap<String, String> {
        val out = LinkedHashMap<String, String>()
        val raw = p(c).getString("map", null)
        if (raw == null) {
            // first run: one example the user can edit or delete
            out["web sitem"] = "https://istanbultasimacilik.com"
            save(c, out)
            return out
        }
        try {
            val o = JSONObject(raw)
            o.keys().forEach { out[it] = o.getString(it) }
        } catch (_: Exception) {}
        return out
    }

    private fun save(c: Context, m: Map<String, String>) {
        val o = JSONObject(); m.forEach { (k, v) -> o.put(k, v) }
        p(c).edit().putString("map", o.toString()).apply()
    }

    fun put(c: Context, name: String, value: String) {
        val m = all(c); m[trLower(name).trim()] = value.trim(); save(c, m)
    }

    /** lines like "babamın ibanı = TR00 … | Ad Soyad"; returns how many were saved */
    fun importText(c: Context, text: String): Int {
        var n = 0
        for (line in text.lines()) {
            val i = line.indexOf('=')
            if (i <= 0) continue
            val k = line.substring(0, i).trim(); val v = line.substring(i + 1).trim()
            if (k.isNotEmpty() && v.isNotEmpty()) { put(c, k, v.split("|").joinToString("|") { it.trim() }); n++ }
        }
        return n
    }

    fun remove(c: Context, name: String) { val m = all(c); m.remove(name); save(c, m) }

    /** regex for a shortcut name inside speech, allowing Turkish endings on the last word: "ibanım" ~ "ibanımı" */
    private fun pattern(name: String): Regex {
        val words = name.split(" ").filter { it.isNotBlank() }.map { Regex.escape(it) }
        return Regex("(?<!\\p{L})" + words.joinToString("\\s+") + "\\p{L}*(?!\\p{L})")
    }

    /** the shortcut mentioned in the text, longest name first */
    fun find(c: Context, text: String): Pair<String, String>? =
        all(c).entries.sortedByDescending { it.key.length }.firstOrNull { pattern(it.key).containsMatchIn(text) }?.toPair()

    fun mentionsLocation(text: String) = Regex("(?<!\\p{L})(mevcut |şu anki |şimdiki |bulunduğum )?konum(um|umu|umuzu|umuz)(?!\\p{L})").containsMatchIn(text) ||
        Regex("(mevcut|şu anki|şimdiki) konum").containsMatchIn(text) || text.contains("nerede olduğumu")

    /** replaces shortcut names in a message with their values */
    fun expand(c: Context, text: String): String {
        var out = text
        for ((k, v) in all(c).entries.sortedByDescending { it.key.length }) out = pattern(k).replace(out, Regex.escapeReplacement(v))
        return out
    }
}
