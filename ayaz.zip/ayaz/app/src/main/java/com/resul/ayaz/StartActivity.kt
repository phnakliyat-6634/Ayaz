package com.resul.ayaz

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle

/** Invisible screen the tile uses so the microphone service starts from the foreground. */
class StartActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED && ModelManager.ready(this)) {
            AyazService.start(this)
        } else {
            startActivity(Intent(this, MainActivity::class.java))
        }
        finish()
    }
}
