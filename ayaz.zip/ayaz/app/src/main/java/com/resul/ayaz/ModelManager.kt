package com.resul.ayaz

import android.content.Context
import org.vosk.Model
import org.vosk.SpeakerModel
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

object ModelManager {
    private const val TR_URL = "https://alphacephei.com/vosk/models/vosk-model-small-tr-0.3.zip"
    private const val SPK_URL = "https://alphacephei.com/vosk/models/vosk-model-spk-0.4.zip"

    fun trDir(c: Context) = File(c.filesDir, "models/tr")
    fun spkDir(c: Context) = File(c.filesDir, "models/spk")

    fun ready(c: Context) =
        File(trDir(c), "ready").exists() && File(spkDir(c), "ready").exists()

    fun download(c: Context, progress: (String) -> Unit, done: (Boolean) -> Unit) {
        Thread {
            try {
                fetch(TR_URL, trDir(c), "Türkçe ses modeli") { progress(it) }
                fetch(SPK_URL, spkDir(c), "Ses tanıma modeli") { progress(it) }
                done(true)
            } catch (e: Exception) {
                progress("İndirme hatası: ${e.message}")
                done(false)
            }
        }.start()
    }

    private fun fetch(url: String, dir: File, label: String, progress: (String) -> Unit) {
        if (File(dir, "ready").exists()) return
        dir.deleteRecursively(); dir.mkdirs()
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 20000; conn.readTimeout = 60000
        conn.instanceFollowRedirects = true
        val total = conn.contentLengthLong
        val zipFile = File(dir.parentFile, "tmp.zip")
        conn.inputStream.use { input ->
            FileOutputStream(zipFile).use { out ->
                val buf = ByteArray(64 * 1024)
                var read = 0L
                var last = -1
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    read += n
                    val pct = if (total > 0) (read * 100 / total).toInt() else -1
                    if (pct != last) { last = pct; progress("$label indiriliyor: %$pct") }
                }
            }
        }
        progress("$label açılıyor…")
        ZipInputStream(zipFile.inputStream()).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                val rel = e.name.substringAfter('/', "")
                if (rel.isEmpty()) continue
                val f = File(dir, rel)
                if (!f.canonicalPath.startsWith(dir.canonicalPath)) continue
                if (e.isDirectory) f.mkdirs() else {
                    f.parentFile?.mkdirs()
                    FileOutputStream(f).use { zin.copyTo(it) }
                }
            }
        }
        zipFile.delete()
        File(dir, "ready").writeText("ok")
    }

    fun load(c: Context): Pair<Model, SpeakerModel> =
        Model(trDir(c).absolutePath) to SpeakerModel(spkDir(c).absolutePath)
}
