package com.resul.ayaz

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick settings tile: tap = start/stop, long press = open Ayaz screen. */
class AyazTile : TileService() {
    companion object {
        fun refresh(c: Context) {
            try { TileService.requestListeningState(c, ComponentName(c, AyazTile::class.java)) } catch (_: Exception) {}
        }
    }

    override fun onStartListening() {
        val t = qsTile ?: return
        t.state = if (AyazService.running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        if (Build.VERSION.SDK_INT >= 29) {
            t.subtitle = when {
                !AyazService.running -> "Kapalı"
                Prefs.sleeping(this) -> "Uykuda"
                else -> "Dinliyor"
            }
        }
        t.updateTile()
    }

    override fun onClick() {
        if (AyazService.running) {
            AyazService.stop(this)
            qsTile?.let { it.state = Tile.STATE_INACTIVE; it.updateTile() }
            return
        }
        val i = Intent(this, StartActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 1, i, PendingIntent.FLAG_IMMUTABLE))
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }
}
