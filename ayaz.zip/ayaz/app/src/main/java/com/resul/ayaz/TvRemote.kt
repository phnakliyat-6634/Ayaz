package com.resul.ayaz

import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Handler
import android.os.Looper

/** Samsung TV over the phone's infrared blaster (Samsung32 protocol, 38 kHz). */
object TvRemote {
    const val POWER = 0xE0E040BFL
    const val VOL_UP = 0xE0E0E01FL
    const val VOL_DOWN = 0xE0E0D02FL
    const val MUTE = 0xE0E0F00FL
    const val CH_UP = 0xE0E048B7L
    const val CH_DOWN = 0xE0E008F7L
    const val SOURCE = 0xE0E0807FL
    val DIGITS = longArrayOf(
        0xE0E08877L, 0xE0E020DFL, 0xE0E0A05FL, 0xE0E0609FL, 0xE0E010EFL,
        0xE0E0906FL, 0xE0E050AFL, 0xE0E030CFL, 0xE0E0B04FL, 0xE0E0708FL
    )

    fun available(c: Context): Boolean {
        val ir = c.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        return ir?.hasIrEmitter() == true
    }

    private fun pattern(code: Long): IntArray {
        val out = ArrayList<Int>()
        out += 4500; out += 4500
        for (i in 31 downTo 0) {
            out += 560
            out += if ((code shr i) and 1L == 1L) 1690 else 560
        }
        out += 560
        return out.toIntArray()
    }

    fun send(c: Context, codes: List<Long>, gapMs: Long = 350) {
        val ir = c.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager ?: return
        val h = Handler(Looper.getMainLooper())
        codes.forEachIndexed { i, code ->
            h.postDelayed({ try { ir.transmit(38000, pattern(code)) } catch (_: Exception) {} }, i * gapMs)
        }
    }

    fun channelCodes(channel: Int): List<Long> =
        channel.toString().map { DIGITS[it - '0'] }
}
