package com.resul.ayaz

import java.util.Calendar

object TurkishTime {
    private val NUMS = listOf(
        "yirmi üç" to "23", "yirmi iki" to "22", "yirmi bir" to "21", "yirmi" to "20",
        "on dokuz" to "19", "on sekiz" to "18", "on yedi" to "17", "on altı" to "16", "on beş" to "15",
        "on dört" to "14", "on üç" to "13", "on iki" to "12", "on bir" to "11",
        "iki" to "2", "üç" to "3", "dört" to "4", "beş" to "5", "altı" to "6",
        "yedi" to "7", "sekiz" to "8", "dokuz" to "9"
    )
    private val MONTHS = listOf("ocak", "şubat", "mart", "nisan", "mayıs", "haziran",
        "temmuz", "ağustos", "eylül", "ekim", "kasım", "aralık")
    private val DAYS = listOf(
        "cumartesi" to Calendar.SATURDAY, "pazartesi" to Calendar.MONDAY,
        "salı" to Calendar.TUESDAY, "çarşamba" to Calendar.WEDNESDAY,
        "perşembe" to Calendar.THURSDAY, "cuma" to Calendar.FRIDAY, "pazar" to Calendar.SUNDAY
    )
    private val DAY_NAMES = mapOf(
        Calendar.MONDAY to "pazartesi", Calendar.TUESDAY to "salı", Calendar.WEDNESDAY to "çarşamba",
        Calendar.THURSDAY to "perşembe", Calendar.FRIDAY to "cuma", Calendar.SATURDAY to "cumartesi",
        Calendar.SUNDAY to "pazar"
    )

    private fun w(word: String) = Regex("(?<!\\p{L})$word(?!\\p{L})")

    fun numWords(t: String): String {
        var s = t
        for ((k, v) in NUMS) s = s.replace(w(k), v)
        s = s.replace(Regex("saat on(?!\\p{L})"), "saat 10").replace(Regex("saat bir(?!\\p{L})"), "saat 1")
        return s
    }

    /** hour and minute, or null */
    fun parseTime(text: String): Pair<Int, Int>? {
        val s = numWords(text)
        var h: Int? = null
        var m = 0
        Regex("(\\d{1,2})[:.](\\d{2})(?!\\d)").find(s)?.let {
            h = it.groupValues[1].toInt(); m = it.groupValues[2].toInt()
        }
        if (h == null) Regex("saat\\s*(\\d{1,2})(?!\\d)").find(s)?.let { h = it.groupValues[1].toInt() }
        if (h == null) Regex("(sabah|öğleden sonra|öğle|akşam|gece)\\s*(?:saat\\s*)?(\\d{1,2})(?!\\d)").find(s)?.let {
            h = it.groupValues[2].toInt()
        }
        if (h == null) Regex("(\\d{1,2})\\s*(?:'?[dt][ae]|'?y?[ae])?\\s+(?:buçuk|alarm|uyandır)").find(s)?.let {
            h = it.groupValues[1].toInt()
        }
        var hour = h ?: return null
        if (m == 0 && Regex("$hour\\s*(?:'?[dt][ae]|'?y?[ae])?\\s*buçuk").containsMatchIn(s)) m = 30
        if (m == 0 && s.contains("çeyrek geçe")) m = 15
        val pm = s.contains("akşam") || s.contains("öğleden sonra") ||
            (s.contains("gece") && hour in 7..11) || (s.contains("öğle") && hour in 1..5)
        if (pm && hour < 12) hour += 12
        if (s.contains("gece") && hour == 12) hour = 0
        return if (hour in 0..23 && m in 0..59) hour to m else null
    }

    /** repeating alarm days as Calendar constants; empty = one time */
    fun repeatDays(text: String): List<Int> {
        val s = text
        if (s.contains("her gün") || s.contains("hergün")) return (1..7).toList()
        if (s.contains("hafta içi")) return listOf(2, 3, 4, 5, 6)
        if (s.contains("hafta sonu")) return listOf(7, 1)
        val repeating = s.contains("her ") || Regex("(leri|ları)(?!\\p{L})").containsMatchIn(s)
        if (!repeating) return emptyList()
        val out = mutableListOf<Int>()
        var rest = s
        for ((name, d) in DAYS) {
            if (rest.contains(name)) { out += d; rest = rest.replace(name, " ") }
        }
        return out
    }

    fun dayNames(days: List<Int>): String = when {
        days.size == 7 -> "her gün"
        days == listOf(2, 3, 4, 5, 6) -> "hafta içi her gün"
        else -> "her " + days.mapNotNull { DAY_NAMES[it] }.joinToString(", ")
    }

    /** date + time for reminders */
    fun parseDate(text: String): Calendar? {
        val s = numWords(text)
        val cal = Calendar.getInstance()
        Regex("(\\d+)\\s*dakika sonra").find(s)?.let {
            cal.add(Calendar.MINUTE, it.groupValues[1].toInt()); return cal
        }
        Regex("(\\d+)\\s*saat sonra").find(s)?.let {
            cal.add(Calendar.HOUR_OF_DAY, it.groupValues[1].toInt()); return cal
        }
        var explicitDate = false
        when {
            s.contains("öbür gün") || s.contains("ertesi gün") -> { cal.add(Calendar.DAY_OF_YEAR, 2); explicitDate = true }
            s.contains("yarın") -> { cal.add(Calendar.DAY_OF_YEAR, 1); explicitDate = true }
            s.contains("bugün") -> explicitDate = true
        }
        val monthMatch = Regex("(\\d{1,2})\\s*(${MONTHS.joinToString("|")})").find(s)
        if (monthMatch != null) {
            val day = monthMatch.groupValues[1].toInt()
            val month = MONTHS.indexOf(monthMatch.groupValues[2])
            val now = Calendar.getInstance()
            cal.set(Calendar.MONTH, month); cal.set(Calendar.DAY_OF_MONTH, day)
            if (cal.before(now) && cal.get(Calendar.DAY_OF_YEAR) != now.get(Calendar.DAY_OF_YEAR)) cal.add(Calendar.YEAR, 1)
            explicitDate = true
        } else if (!explicitDate) {
            var rest = s
            for ((name, d) in DAYS) {
                if (rest.contains(name)) {
                    rest = rest.replace(name, " ")
                    var diff = (d - cal.get(Calendar.DAY_OF_WEEK) + 7) % 7
                    if (diff == 0) diff = 7
                    cal.add(Calendar.DAY_OF_YEAR, diff)
                    if (s.contains("haftaya") && diff < 7) cal.add(Calendar.DAY_OF_YEAR, 7)
                    explicitDate = true
                    break
                }
            }
            if (!explicitDate && s.contains("haftaya")) { cal.add(Calendar.DAY_OF_YEAR, 7); explicitDate = true }
        }
        val time = parseTime(s)
        cal.set(Calendar.HOUR_OF_DAY, time?.first ?: 9)
        cal.set(Calendar.MINUTE, time?.second ?: 0)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        if (!explicitDate && time == null) return null
        if (!explicitDate && cal.before(Calendar.getInstance())) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal
    }

    fun reminderTitle(text: String): String {
        var s = numWords(text)
        val remove = listOf(
            "\\d+\\s*(dakika|saat) sonra", "öbür gün", "ertesi gün", "yarın", "bugün", "haftaya",
            "\\d{1,2}\\s*(${MONTHS.joinToString("|")})(\\s*'?(t|d)[ae]|'?[ıiuü]?n[dt][ae])?",
            "saat\\s*\\d{1,2}([:.]\\d{2})?('?[dt][ae]|'?y?[ae])?", "\\d{1,2}[:.]\\d{2}('?[dt][ae])?",
            "(sabah|öğleden sonra|öğle|akşam|gece)\\s*\\d{0,2}('?[dt][ae])?", "buçuk('?[dt][ae])?",
            "(${DAYS.joinToString("|") { it.first }})('?[yn]?[ae]|'?[dt][ae]|'?[ıiuü])?",
            "hatırlatma (yap|ekle|kur|oluştur)", "hatırlatıcı (kur|ekle)", "bana", "hatırlat(sana)?",
            "takvime (ekle|kaydet|yaz)", "takvime", "için", "diye", "ekle"
        )
        for (r in remove) s = s.replace(Regex("(?<!\\p{L})($r)(?!\\p{L})"), " ")
        s = s.replace(Regex("\\s+"), " ").trim(' ', ',', '.')
        return if (s.isBlank()) "Hatırlatma" else capFirst(s)
    }
}
