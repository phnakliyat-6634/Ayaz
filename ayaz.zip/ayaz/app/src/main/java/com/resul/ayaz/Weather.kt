package com.resul.ayaz

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt

/** Weather from Open-Meteo (free, no key), spoken in short Turkish. */
object Weather {
    fun describe(code: Int): String = when (code) {
        0 -> "güneşli ve açık"
        1 -> "çoğunlukla güneşli"
        2 -> "parçalı bulutlu"
        3 -> "kapalı ve bulutlu"
        45, 48 -> "sisli"
        51, 53, 55 -> "çiseleyen yağmurlu"
        56, 57 -> "dondurucu çisentili"
        61 -> "hafif yağmurlu"
        63 -> "yağmurlu"
        65 -> "kuvvetli yağmurlu"
        66, 67 -> "dondurucu yağmurlu"
        71 -> "hafif karlı"
        73 -> "karlı"
        75 -> "yoğun kar yağışlı"
        77 -> "kar taneli"
        80 -> "hafif sağanak yağışlı"
        81 -> "sağanak yağışlı"
        82 -> "şiddetli sağanak yağışlı"
        85, 86 -> "kar sağanaklı"
        95 -> "gök gürültülü fırtınalı"
        96, 99 -> "dolu ve fırtınalı"
        else -> "değişken"
    }

    private fun get(url: String): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000
        return JSONObject(c.inputStream.bufferedReader().readText())
    }

    /** a place name -> lat, lon, display name */
    fun geocode(name: String): Triple<Double, Double, String>? {
        val o = get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=tr&name=" + URLEncoder.encode(name, "UTF-8"))
        val r = o.optJSONArray("results")?.optJSONObject(0) ?: return null
        return Triple(r.getDouble("latitude"), r.getDouble("longitude"), r.optString("name", name))
    }

    /** day 0 = today, 1 = tomorrow */
    fun report(lat: Double, lon: Double, place: String?, day: Int): String {
        val o = get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,weather_code" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
            "&timezone=auto&forecast_days=3")
        val d = o.getJSONObject("daily")
        val max = d.getJSONArray("temperature_2m_max").getDouble(day).roundToInt()
        val min = d.getJSONArray("temperature_2m_min").getDouble(day).roundToInt()
        val rain = d.getJSONArray("precipitation_probability_max").optInt(day, -1)
        val where = if (place.isNullOrBlank()) "" else locative(place) + " "
        val rainTxt = if (rain >= 0) " Yağmur ihtimali yüzde $rain." else ""
        return if (day == 0) {
            val cur = o.getJSONObject("current")
            val temp = cur.getDouble("temperature_2m").roundToInt()
            val desc = describe(cur.getInt("weather_code"))
            "Şu an ${where}hava $temp derece, $desc. Bugün en yüksek $max, en düşük $min derece.$rainTxt"
        } else {
            val desc = describe(d.getJSONArray("weather_code").getInt(day))
            val dayName = if (day == 1) "Yarın" else "Öbür gün"
            "$dayName ${where}hava $desc, en yüksek $max, en düşük $min derece.$rainTxt"
        }
    }
}
