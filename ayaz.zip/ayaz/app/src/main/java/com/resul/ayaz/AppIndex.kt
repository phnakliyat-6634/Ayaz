package com.resul.ayaz

import android.content.Context
import android.content.Intent

data class AppHit(val label: String, val pkg: String, val score: Double)

object AppIndex {
    private var cache: List<Pair<String, String>> = emptyList()
    private var cachedAt = 0L

    private fun apps(c: Context): List<Pair<String, String>> {
        if (System.currentTimeMillis() - cachedAt < 5 * 60_000 && cache.isNotEmpty()) return cache
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        cache = pm.queryIntentActivities(i, 0).map {
            it.loadLabel(pm).toString() to it.activityInfo.packageName
        }.distinctBy { it.second }
        cachedAt = System.currentTimeMillis()
        return cache
    }

    fun find(c: Context, spoken: String): List<AppHit> {
        val q = trLower(spoken)
        val qShort = q.replace(Regex("[ıiuüae]$"), "")
        return apps(c).map { (label, pkg) ->
            val l = trLower(label)
            AppHit(label, pkg, maxOf(nameScore(q, l), nameScore(qShort, l) - 0.05))
        }.sortedByDescending { it.score }.take(3)
    }

    fun launch(c: Context, pkg: String): Boolean {
        val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { c.startActivity(i); true } catch (e: Exception) { false }
    }

    fun installed(c: Context, pkg: String): Boolean =
        c.packageManager.getLaunchIntentForPackage(pkg) != null
}
