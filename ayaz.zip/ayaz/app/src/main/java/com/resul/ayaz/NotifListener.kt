package com.resul.ayaz

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

data class Msg(val sender: String, val text: String, val app: String, var read: Boolean = false)

class NotifListener : NotificationListenerService() {
    companion object {
        @Volatile var connected = false
        private val msgs = ArrayList<Msg>()
        private val APPS = mapOf(
            "com.whatsapp" to "WhatsApp", "com.whatsapp.w4b" to "WhatsApp",
            "com.google.android.apps.messaging" to "Mesajlar", "com.android.mms" to "Mesajlar",
            "com.samsung.android.messaging" to "Mesajlar", "org.telegram.messenger" to "Telegram",
            "com.instagram.android" to "Instagram"
        )

        fun unread(): List<Msg> = synchronized(msgs) { msgs.filter { !it.read } }
        fun markRead() = synchronized(msgs) { msgs.forEach { it.read = true } }
    }

    override fun onListenerConnected() { connected = true }
    override fun onListenerDisconnected() { connected = false }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification ?: return
        val app = APPS[sbn.packageName] ?: if (n.category == Notification.CATEGORY_MESSAGE) "mesaj" else return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.extras ?: return
        val sender = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        if (Regex("^\\d+ (yeni )?mesaj").containsMatchIn(text) || text.isBlank()) return
        synchronized(msgs) {
            if (msgs.lastOrNull()?.let { it.sender == sender && it.text == text } == true) return
            msgs += Msg(sender, text, app)
            while (msgs.size > 40) msgs.removeAt(0)
        }
    }
}
