package com.resul.ayaz

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Checks GitHub Releases of the user's repo and installs a newer APK. */
object Updater {
    fun check(c: Context, interactive: Boolean, say: (String) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        val out: (String) -> Unit = { m -> main.post { say(m) } }
        val repo = Prefs.repo(c)
        if (repo.isBlank() || !repo.contains("/")) { out("Önce Ayaz ekranında GitHub depo adını gir"); return }
        Thread {
            try {
                val conn = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
                conn.setRequestProperty("Accept", "application/vnd.github+json")
                val json = JSONObject(conn.inputStream.bufferedReader().readText())
                val latest = json.optString("tag_name").removePrefix("v").toIntOrNull() ?: 0
                if (latest <= BuildConfig.VERSION_CODE) { if (interactive) out("Ayaz güncel. Sürüm ${BuildConfig.VERSION_CODE}"); return@Thread }
                val assets = json.getJSONArray("assets")
                var url: String? = null
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name").endsWith(".apk")) url = a.optString("browser_download_url")
                }
                if (url == null) { out("Yeni sürümde APK bulunamadı"); return@Thread }
                out("Yeni sürüm $latest indiriliyor")
                val f = File(c.cacheDir, "ayaz-update.apk")
                URL(url).openStream().use { input -> f.outputStream().use { input.copyTo(it) } }
                val uri = FileProvider.getUriForFile(c, "com.resul.ayaz.files", f)
                val i = Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                main.post { try { c.startActivity(i) } catch (e: Exception) { say("Kurulum ekranı açılamadı") } }
                out("Kurulum ekranını açtım, Güncelle'ye bas")
            } catch (e: Exception) {
                out("Güncelleme kontrol edilemedi")
            }
        }.start()
    }
}
