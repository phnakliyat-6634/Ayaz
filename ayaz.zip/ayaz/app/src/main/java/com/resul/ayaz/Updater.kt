package com.resul.ayaz

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Checks GitHub Releases of the user's repo and installs a newer APK through
 * Android's own installer session (the method app stores use), which works on
 * Xiaomi where opening the file directly fails with "package invalid".
 */
object Updater {
    private fun open(url: String, accept: String): HttpURLConnection {
        var u = url
        repeat(6) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 20000; c.readTimeout = 60000
            c.setRequestProperty("Accept", accept)
            c.setRequestProperty("User-Agent", "Ayaz")
            val code = c.responseCode
            if (code in 300..399) { u = c.getHeaderField("Location") ?: return c; c.disconnect() } else return c
        }
        throw Exception("çok fazla yönlendirme")
    }

    fun releasePage(c: Context) = "https://github.com/${Prefs.repo(c)}/releases/latest"

    fun check(c: Context, interactive: Boolean, say: (String) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        val out: (String) -> Unit = { m -> main.post { say(m) } }
        val repo = Prefs.repo(c)
        if (repo.isBlank() || !repo.contains("/")) { out("Önce Ayaz ekranında GitHub depo adını gir"); return }
        Thread {
            try {
                val api = open("https://api.github.com/repos/$repo/releases/latest", "application/vnd.github+json")
                val json = JSONObject(api.inputStream.bufferedReader().readText())
                val latest = json.optString("tag_name").removePrefix("v").toIntOrNull() ?: 0
                if (latest <= BuildConfig.VERSION_CODE) { if (interactive) out("Ayaz güncel. Sürüm ${BuildConfig.VERSION_CODE}"); return@Thread }
                val assets = json.getJSONArray("assets")
                var url: String? = null; var size = -1L
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name").endsWith(".apk")) { url = a.optString("browser_download_url"); size = a.optLong("size", -1) }
                }
                if (url == null) { out("Yeni sürümde APK bulunamadı"); return@Thread }
                out("Yeni sürüm $latest indiriliyor")

                val f = File(c.cacheDir, "ayaz-update.apk")
                val dl = open(url, "application/octet-stream")
                dl.inputStream.use { input -> f.outputStream().use { input.copyTo(it) } }
                // make sure it really is a complete APK (zip starts with "PK")
                val head = f.inputStream().use { val b = ByteArray(2); it.read(b); b }
                if (head[0] != 'P'.code.toByte() || head[1] != 'K'.code.toByte() || (size > 0 && f.length() != size)) {
                    throw Exception("indirilen dosya eksik (${f.length()} / $size)")
                }

                val pi = c.packageManager.packageInstaller
                val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
                params.setAppPackageName(c.packageName)
                val id = pi.createSession(params)
                pi.openSession(id).use { s ->
                    f.inputStream().use { input ->
                        s.openWrite("ayaz.apk", 0, f.length()).use { o -> input.copyTo(o); s.fsync(o) }
                    }
                    val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                    val cb = PendingIntent.getBroadcast(c, id, Intent(c, InstallReceiver::class.java), flags)
                    s.commit(cb.intentSender)
                }
                out("Kurulum onayı geliyor, Güncelle'ye bas")
            } catch (e: Exception) {
                Prefs.log(c, "Güncelleme hatası: ${e.message}")
                out("Otomatik kuramadım, indirme sayfasını açıyorum")
                main.post {
                    try { c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(releasePage(c))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                }
            }
        }.start()
    }
}

/** receives the installer's answer; shows the system "Update?" screen when it asks for the user */
class InstallReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, -99)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val confirm = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT) ?: return
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { c.startActivity(confirm) } catch (_: Exception) {}
            }
            PackageInstaller.STATUS_SUCCESS -> Prefs.log(c, "Güncelleme kuruldu")
            else -> {
                val msg = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "bilinmeyen"
                Prefs.log(c, "Kurulum başarısız: $msg")
                try {
                    c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Updater.releasePage(c))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {}
            }
        }
    }
}
