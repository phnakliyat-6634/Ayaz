package com.resul.ayaz

import android.animation.ValueAnimator
import android.app.Activity
import android.app.KeyguardManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date

/** Effect screen shown over the lock screen; swipe up to open. */
class WakeActivity : Activity() {
    private lateinit var panel: LinearLayout
    private lateinit var glow: View
    private var startY = 0f
    private val h = Handler(Looper.getMainLooper())
    private var detector: MotionDetector? = null
    private var opened = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        glow = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                intArrayOf(Color.parseColor("#FF9F1C"), Color.TRANSPARENT))
            alpha = 0f
        }
        root.addView(glow, FrameLayout.LayoutParams(-1, -1))

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#0D1220"), Color.parseColor("#121829"), Color.parseColor("#2B3566")))
            setPadding(48, 180, 48, 120)
        }
        val clock = TextView(this).apply {
            text = SimpleDateFormat("HH:mm", TR).format(Date()); textSize = 84f
            setTextColor(Color.parseColor("#E7EBF6")); gravity = Gravity.CENTER
        }
        val date = TextView(this).apply {
            text = SimpleDateFormat("d MMMM EEEE", TR).format(Date()); textSize = 18f
            setTextColor(Color.parseColor("#98A1BC")); gravity = Gravity.CENTER
        }
        val spacer = View(this)
        val name = TextView(this).apply {
            text = "Ayaz"; textSize = 44f; setTextColor(Color.parseColor("#FF9F1C")); gravity = Gravity.CENTER
            paint.isFakeBoldText = true
        }
        val hint = TextView(this).apply {
            text = "↑\nAçmak için elini kameranın önünde yukarı kaldır\nya da parmağınla yukarı kaydır"; textSize = 16f
            setTextColor(Color.parseColor("#98A1BC")); gravity = Gravity.CENTER
        }
        panel.addView(clock); panel.addView(date)
        panel.addView(spacer, LinearLayout.LayoutParams(-1, 0, 1f))
        panel.addView(name); panel.addView(hint)
        root.addView(panel, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        panel.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> startY = e.rawY
                MotionEvent.ACTION_MOVE -> {
                    val dy = (e.rawY - startY).coerceAtMost(0f)
                    v.translationY = dy
                    glow.alpha = (-dy / v.height * 2f).coerceIn(0f, 1f)
                }
                MotionEvent.ACTION_UP -> {
                    if (-v.translationY > v.height * 0.25f) open() else v.animate().translationY(0f).setDuration(200).start()
                }
            }
            true
        }
        if (intent.getBooleanExtra("auto", false)) {
            // command given with the screen off: no swipe needed, unlock and get out of the way
            panel.visibility = View.INVISIBLE
            val km = getSystemService(KeyguardManager::class.java)
            if (km.isKeyguardLocked) {
                km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                    override fun onDismissSucceeded() { finish() }
                    override fun onDismissCancelled() { finish() }
                    override fun onDismissError() { finish() }
                })
                h.postDelayed({ finish() }, 8000)
            } else h.postDelayed({ finish() }, 300)
            return
        }
        h.postDelayed({ finish() }, 30_000)
    }

    override fun onResume() {
        super.onResume()
        if (intent.getBooleanExtra("auto", false)) return
        detector = MotionDetector(this) { g -> if (g == MotionDetector.Gesture.UP) open() }.also { it.start() }
    }

    override fun onPause() { detector?.stop(); detector = null; super.onPause() }

    private fun open() {
        if (opened) return
        opened = true
        detector?.stop()
        ValueAnimator.ofFloat(panel.translationY, -panel.height.toFloat()).apply {
            duration = 450; interpolator = DecelerateInterpolator()
            addUpdateListener { panel.translationY = it.animatedValue as Float }
            start()
        }
        glow.animate().alpha(1f).setDuration(200).withEndAction {
            glow.animate().alpha(0f).setDuration(500).start()
        }.start()
        h.postDelayed({
            val km = getSystemService(KeyguardManager::class.java)
            if (km.isKeyguardLocked) km.requestDismissKeyguard(this, null)
            finish()
            overridePendingTransition(0, android.R.anim.fade_out)
        }, 480)
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }
}
